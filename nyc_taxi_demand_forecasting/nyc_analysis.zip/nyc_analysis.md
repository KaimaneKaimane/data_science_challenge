```python
import pandas as pd
from datetime import datetime
```


```python
raw_data = pd.read_csv('./data/nyc_taxi_data.csv')
raw_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>timestamp</th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>temperature</th>
      <th>wind_direction</th>
      <th>wind_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.761700e+04</td>
      <td>17617.000000</td>
      <td>1.761700e+04</td>
      <td>1.761700e+04</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.482720e+09</td>
      <td>22826.868252</td>
      <td>5.440456e+04</td>
      <td>2.274162e+05</td>
      <td>65.284768</td>
      <td>1017.387087</td>
      <td>286.702957</td>
      <td>189.917370</td>
      <td>3.301706</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.533143e+07</td>
      <td>10768.365771</td>
      <td>3.308981e+05</td>
      <td>1.065534e+05</td>
      <td>20.913299</td>
      <td>8.071362</td>
      <td>9.828138</td>
      <td>110.912245</td>
      <td>2.088770</td>
    </tr>
    <tr>
      <th>min</th>
      <td>9.783072e+08</td>
      <td>1.000000</td>
      <td>-3.337066e+06</td>
      <td>2.300000e+00</td>
      <td>10.000000</td>
      <td>988.000000</td>
      <td>255.070000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.467310e+09</td>
      <td>14409.000000</td>
      <td>2.980201e+04</td>
      <td>1.420672e+05</td>
      <td>49.000000</td>
      <td>1013.000000</td>
      <td>278.890000</td>
      <td>80.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.483153e+09</td>
      <td>25483.000000</td>
      <td>4.459818e+04</td>
      <td>2.539055e+05</td>
      <td>65.000000</td>
      <td>1017.000000</td>
      <td>287.440000</td>
      <td>210.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.498997e+09</td>
      <td>30330.000000</td>
      <td>5.257208e+04</td>
      <td>3.024059e+05</td>
      <td>83.000000</td>
      <td>1022.000000</td>
      <td>294.850000</td>
      <td>287.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.626186e+09</td>
      <td>59077.000000</td>
      <td>1.913556e+07</td>
      <td>1.550589e+06</td>
      <td>100.000000</td>
      <td>1044.000000</td>
      <td>308.370000</td>
      <td>360.000000</td>
      <td>18.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas_profiling as pp
# pp.ProfileReport(raw_data)
```


```python
def to_datetime(epoch):
    return datetime.fromtimestamp(epoch).strftime('%Y-%m-%d %H:%M:%S')

raw_data['timestamp'] = raw_data['timestamp'].apply(to_datetime)
raw_data = raw_data.sort_values(by=['timestamp'])
raw_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>timestamp</th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>temperature</th>
      <th>weather_description</th>
      <th>wind_direction</th>
      <th>wind_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3867</th>
      <td>2001-01-01 01:00:00</td>
      <td>1</td>
      <td>0.00</td>
      <td>3.80</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>13038</th>
      <td>2001-01-02 00:00:00</td>
      <td>1</td>
      <td>0.56</td>
      <td>11.80</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1816</th>
      <td>2001-01-06 07:00:00</td>
      <td>1</td>
      <td>0.00</td>
      <td>3.80</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3648</th>
      <td>2003-01-01 00:00:00</td>
      <td>1</td>
      <td>3.15</td>
      <td>17.30</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7885</th>
      <td>2003-01-01 01:00:00</td>
      <td>7</td>
      <td>19.28</td>
      <td>85.60</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>12808</th>
      <td>2018-04-30 19:00:00</td>
      <td>3</td>
      <td>4.15</td>
      <td>30.36</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10624</th>
      <td>2018-05-22 02:00:00</td>
      <td>1</td>
      <td>1.58</td>
      <td>11.76</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5192</th>
      <td>2018-05-22 03:00:00</td>
      <td>3</td>
      <td>5.31</td>
      <td>29.66</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6079</th>
      <td>2041-11-15 03:00:00</td>
      <td>1</td>
      <td>8.67</td>
      <td>31.56</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10095</th>
      <td>2053-03-21 17:00:00</td>
      <td>3</td>
      <td>0.76</td>
      <td>5.80</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>17617 rows × 10 columns</p>
</div>




```python
raw_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>temperature</th>
      <th>wind_direction</th>
      <th>wind_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>17617.000000</td>
      <td>1.761700e+04</td>
      <td>1.761700e+04</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>22826.868252</td>
      <td>5.440456e+04</td>
      <td>2.274162e+05</td>
      <td>65.284768</td>
      <td>1017.387087</td>
      <td>286.702957</td>
      <td>189.917370</td>
      <td>3.301706</td>
    </tr>
    <tr>
      <th>std</th>
      <td>10768.365771</td>
      <td>3.308981e+05</td>
      <td>1.065534e+05</td>
      <td>20.913299</td>
      <td>8.071362</td>
      <td>9.828138</td>
      <td>110.912245</td>
      <td>2.088770</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>-3.337066e+06</td>
      <td>2.300000e+00</td>
      <td>10.000000</td>
      <td>988.000000</td>
      <td>255.070000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>14409.000000</td>
      <td>2.980201e+04</td>
      <td>1.420672e+05</td>
      <td>49.000000</td>
      <td>1013.000000</td>
      <td>278.890000</td>
      <td>80.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>25483.000000</td>
      <td>4.459818e+04</td>
      <td>2.539055e+05</td>
      <td>65.000000</td>
      <td>1017.000000</td>
      <td>287.440000</td>
      <td>210.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>30330.000000</td>
      <td>5.257208e+04</td>
      <td>3.024059e+05</td>
      <td>83.000000</td>
      <td>1022.000000</td>
      <td>294.850000</td>
      <td>287.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>59077.000000</td>
      <td>1.913556e+07</td>
      <td>1.550589e+06</td>
      <td>100.000000</td>
      <td>1044.000000</td>
      <td>308.370000</td>
      <td>360.000000</td>
      <td>18.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as mpl

raw_data.plot(
    x='timestamp', 
    y=[
        'passenger_count', 
        'trip_distance', 
        'total_amount', 
        'humidity', 
        'pressure', 
        'temperature', 
        'wind_direction',
        'wind_speed'
    ], 
    figsize=(30,30), 
    grid=True, 
    subplots=True)
```




    array([<matplotlib.axes._subplots.AxesSubplot object at 0x7f285fe19438>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285fe93dd8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f286f2f9208>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f286f2a85f8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f286f2599e8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285fe43dd8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285d883208>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285d8b45c0>],
          dtype=object)




![png](output_5_1.png)



```python
start = "2016-01-01 00:00:00"
end = "2017-12-31 00:00:00"

raw_data = raw_data[raw_data['timestamp'] >= start]
raw_data = raw_data[raw_data['timestamp'] <= end]
raw_data.plot(
    x='timestamp', 
    y=[
        'passenger_count', 
        'trip_distance', 
        'total_amount', 
        'humidity', 
        'pressure', 
        'temperature', 
        'wind_direction',
        'wind_speed'
    ], 
    figsize=(30,30), 
    grid=True, 
    subplots=True)
```




    array([<matplotlib.axes._subplots.AxesSubplot object at 0x7f285c114f28>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c2af278>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c2dc668>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c28ca58>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c23fe48>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c200278>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c1b0668>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285c1e2a20>],
          dtype=object)




![png](output_6_1.png)



```python
raw_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>temperature</th>
      <th>wind_direction</th>
      <th>wind_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>17535.000000</td>
      <td>1.753500e+04</td>
      <td>1.753500e+04</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
      <td>15999.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>22910.101568</td>
      <td>5.462006e+04</td>
      <td>2.282789e+05</td>
      <td>65.284768</td>
      <td>1017.387087</td>
      <td>286.702957</td>
      <td>189.917370</td>
      <td>3.301706</td>
    </tr>
    <tr>
      <th>std</th>
      <td>10706.562379</td>
      <td>3.316545e+05</td>
      <td>1.059265e+05</td>
      <td>20.913299</td>
      <td>8.071362</td>
      <td>9.828138</td>
      <td>110.912245</td>
      <td>2.088770</td>
    </tr>
    <tr>
      <th>min</th>
      <td>9.000000</td>
      <td>-3.337066e+06</td>
      <td>1.208500e+02</td>
      <td>10.000000</td>
      <td>988.000000</td>
      <td>255.070000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>14587.500000</td>
      <td>3.009255e+04</td>
      <td>1.437879e+05</td>
      <td>49.000000</td>
      <td>1013.000000</td>
      <td>278.890000</td>
      <td>80.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>25524.000000</td>
      <td>4.466106e+04</td>
      <td>2.545449e+05</td>
      <td>65.000000</td>
      <td>1017.000000</td>
      <td>287.440000</td>
      <td>210.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>30351.000000</td>
      <td>5.263006e+04</td>
      <td>3.025978e+05</td>
      <td>83.000000</td>
      <td>1022.000000</td>
      <td>294.850000</td>
      <td>287.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>59077.000000</td>
      <td>1.913556e+07</td>
      <td>1.550589e+06</td>
      <td>100.000000</td>
      <td>1044.000000</td>
      <td>308.370000</td>
      <td>360.000000</td>
      <td>18.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
start = "2016-01-01 00:00:00"
end = "2017-12-31 00:00:00"

raw_data = raw_data[raw_data['passenger_count'] < raw_data['passenger_count'].quantile(.95)]
raw_data = raw_data[raw_data['trip_distance'] < raw_data['trip_distance'].quantile(.95)]
raw_data = raw_data[raw_data['total_amount'] < raw_data['total_amount'].quantile(.95)]
raw_data = raw_data[raw_data['passenger_count'] > raw_data['passenger_count'].quantile(.05)]
raw_data = raw_data[raw_data['trip_distance'] > raw_data['trip_distance'].quantile(.05)]
raw_data = raw_data[raw_data['total_amount'] > raw_data['total_amount'].quantile(.05)]

raw_data.plot(
    x='timestamp', 
    y=[
        'passenger_count', 
        'trip_distance', 
        'total_amount', 
        'humidity', 
        'pressure', 
        'temperature', 
        'wind_direction',
        'wind_speed'
    ], 
    figsize=(30,30), 
    grid=True, 
    subplots=True)
```




    array([<matplotlib.axes._subplots.AxesSubplot object at 0x7f285c24dd68>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a87a940>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a81e860>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a7d0c50>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a78f080>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a741470>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a6f2860>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285a724c18>],
          dtype=object)




![png](output_8_1.png)



```python
raw_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
      <th>humidity</th>
      <th>pressure</th>
      <th>temperature</th>
      <th>wind_direction</th>
      <th>wind_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>12887.000000</td>
      <td>12887.000000</td>
      <td>12887.000000</td>
      <td>11715.000000</td>
      <td>11715.000000</td>
      <td>11715.000000</td>
      <td>11715.000000</td>
      <td>11715.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>23401.253123</td>
      <td>42007.932218</td>
      <td>231049.871085</td>
      <td>67.027828</td>
      <td>1017.487751</td>
      <td>286.759591</td>
      <td>188.826889</td>
      <td>3.143235</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7641.699913</td>
      <td>11101.713935</td>
      <td>73005.025964</td>
      <td>20.348037</td>
      <td>8.000123</td>
      <td>9.920466</td>
      <td>111.969336</td>
      <td>1.976506</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4952.000000</td>
      <td>13808.930000</td>
      <td>71952.010000</td>
      <td>13.000000</td>
      <td>988.000000</td>
      <td>256.360000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>18889.500000</td>
      <td>35816.510000</td>
      <td>179391.405000</td>
      <td>51.000000</td>
      <td>1013.000000</td>
      <td>278.780000</td>
      <td>73.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>25358.000000</td>
      <td>44376.180000</td>
      <td>252359.200000</td>
      <td>67.000000</td>
      <td>1017.000000</td>
      <td>287.550000</td>
      <td>210.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>28884.500000</td>
      <td>50074.690000</td>
      <td>288341.145000</td>
      <td>86.000000</td>
      <td>1022.000000</td>
      <td>295.000000</td>
      <td>286.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>37930.000000</td>
      <td>61942.420000</td>
      <td>336980.280000</td>
      <td>100.000000</td>
      <td>1044.000000</td>
      <td>308.370000</td>
      <td>360.000000</td>
      <td>18.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
start = "2017-02-01 00:00:00"
end = "2017-02-31 00:00:00"

month_display = raw_data[raw_data['timestamp'] >= start]
month_display = month_display[month_display['timestamp'] <= end]
month_display.plot(
    x='timestamp', 
    y=[
        'passenger_count', 
        'trip_distance', 
        'total_amount', 
        'humidity', 
        'pressure', 
        'temperature', 
        'wind_direction',
        'wind_speed'
    ], 
    figsize=(30,30), 
    grid=True, 
    subplots=True)
```




    array([<matplotlib.axes._subplots.AxesSubplot object at 0x7f2853165c18>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f28530fda58>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f28530b30b8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f28530e16d8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2853090cf8>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f285304d358>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852ffb978>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852facf60>],
          dtype=object)




![png](output_10_1.png)



```python
start = "2017-02-01 00:00:00"
end = "2017-02-07 00:00:00"

week_display = raw_data[raw_data['timestamp'] >= start]
week_display = week_display[week_display['timestamp'] <= end]
week_display.plot(
    x='timestamp', 
    y=[
        'passenger_count', 
        'trip_distance', 
        'total_amount', 
        'humidity', 
        'pressure', 
        'temperature', 
        'wind_direction',
        'wind_speed'
    ], 
    figsize=(30,30), 
    grid=True, 
    subplots=True)
```




    array([<matplotlib.axes._subplots.AxesSubplot object at 0x7f2852cbe358>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852c49780>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852bf6b70>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852baaf60>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852be7390>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852b99780>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852b4ab70>,
           <matplotlib.axes._subplots.AxesSubplot object at 0x7f2852afcf28>],
          dtype=object)




![png](output_11_1.png)



```python
import seaborn as sn
import matplotlib.pyplot as plt

corrMatrix = raw_data.corr()
sn.heatmap(corrMatrix, annot=True)
plt.show()
```


![png](output_12_0.png)



```python
features = raw_data.set_index(
    pd.DatetimeIndex(raw_data['timestamp'], freq='infer')
)[['passenger_count', 'trip_distance', 'total_amount']]
features
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>total_amount</th>
    </tr>
    <tr>
      <th>timestamp</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-01 05:00:00</th>
      <td>27840</td>
      <td>58138.22</td>
      <td>270881.18</td>
    </tr>
    <tr>
      <th>2016-01-01 06:00:00</th>
      <td>14338</td>
      <td>34279.84</td>
      <td>150000.88</td>
    </tr>
    <tr>
      <th>2016-01-01 07:00:00</th>
      <td>10509</td>
      <td>28130.91</td>
      <td>116414.74</td>
    </tr>
    <tr>
      <th>2016-01-01 08:00:00</th>
      <td>8808</td>
      <td>23002.57</td>
      <td>95785.34</td>
    </tr>
    <tr>
      <th>2016-01-01 09:00:00</th>
      <td>8317</td>
      <td>20771.22</td>
      <td>87188.47</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2017-12-30 20:00:00</th>
      <td>25771</td>
      <td>38907.11</td>
      <td>216848.70</td>
    </tr>
    <tr>
      <th>2017-12-30 21:00:00</th>
      <td>20674</td>
      <td>34062.91</td>
      <td>184267.43</td>
    </tr>
    <tr>
      <th>2017-12-30 22:00:00</th>
      <td>21254</td>
      <td>38452.34</td>
      <td>197187.19</td>
    </tr>
    <tr>
      <th>2017-12-30 23:00:00</th>
      <td>22562</td>
      <td>39538.88</td>
      <td>203581.10</td>
    </tr>
    <tr>
      <th>2017-12-31 00:00:00</th>
      <td>20885</td>
      <td>39600.40</td>
      <td>197072.78</td>
    </tr>
  </tbody>
</table>
<p>12887 rows × 3 columns</p>
</div>




```python
print(features.iloc[:20])
```

                         passenger_count  trip_distance  total_amount
    timestamp                                                        
    2016-01-01 05:00:00            27840       58138.22     270881.18
    2016-01-01 06:00:00            14338       34279.84     150000.88
    2016-01-01 07:00:00            10509       28130.91     116414.74
    2016-01-01 08:00:00             8808       23002.57      95785.34
    2016-01-01 09:00:00             8317       20771.22      87188.47
    2016-01-01 10:00:00            10593       23233.90      99049.01
    2016-01-01 11:00:00            14822       28702.94     126947.44
    2016-01-01 12:00:00            21016       35825.07     164693.14
    2016-01-01 13:00:00            25247       43193.68     199481.65
    2016-01-01 14:00:00            28167       49148.37     227650.75
    2016-01-01 15:00:00            29968       54603.84     252448.61
    2016-01-01 16:00:00            28706       51845.25     243802.22
    2016-01-01 17:00:00            26575       46883.73     221980.84
    2016-01-01 18:00:00            27918       49235.82     238352.19
    2016-01-01 19:00:00            29700       48557.21     241944.11
    2016-01-01 20:00:00            28117       42713.15     219707.65
    2016-01-01 21:00:00            23646       39381.59     196465.85
    2016-01-01 22:00:00            23771       39925.15     194651.55
    2016-01-01 23:00:00            24542       43197.37     209319.09
    2016-01-02 00:00:00            23143       41250.95     196123.18



```python
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error
import warnings
warnings.filterwarnings("ignore")

available_observations = pd.DataFrame(train_set)

test_set_site = .15 # 15%
test_set_split_idx = int((1.0 - test_set_site) *len(features))

def update_history(split_idx):
    return features.iloc[:split_idx][['passenger_count']]

train_set = update_history(test_set_split_idx)
test_set = features.iloc[test_set_split_idx:][['passenger_count']]

test_set_list = test_set['passenger_count'].tolist()

available_observations = train_set

count = 0
test_samples = len(test_set_list)
predictions = list()

for observation in test_set_list:
    model = ARIMA(available_observations, order=(1,0,0))
    model_fit = model.fit(disp=0)
    forecast = model_fit.forecast()
    
    count = count + 1
    available_observations = update_history(test_set_split_idx + count)
    predictions.append(forecast[0])
    print('{}/{} - predicted={} | {}=expected'.format(count, test_samples, forecast[0], observation))
    

mse = mean_squared_error(test_set_list, predictions)
print('Test MSE:', mse)
```

    1/1934 - predicted=[28113.26449873] | 27902=expected
    2/1934 - predicted=[27116.32282818] | 31428=expected
    3/1934 - predicted=[30019.59855937] | 30742=expected
    4/1934 - predicted=[29454.98269277] | 29305=expected
    5/1934 - predicted=[28271.94821009] | 25896=expected
    6/1934 - predicted=[25465.22193622] | 21745=expected
    7/1934 - predicted=[22047.67962237] | 15958=expected
    8/1934 - predicted=[17283.05747762] | 9881=expected
    9/1934 - predicted=[12278.4735771] | 6073=expected
    10/1934 - predicted=[9140.51644419] | 7145=expected
    11/1934 - predicted=[10022.21420977] | 12225=expected
    12/1934 - predicted=[14206.37171226] | 16938=expected
    13/1934 - predicted=[18087.79239756] | 22685=expected
    14/1934 - predicted=[22820.29004408] | 25563=expected
    15/1934 - predicted=[25190.1311255] | 27772=expected
    16/1934 - predicted=[27009.17177093] | 28400=expected
    17/1934 - predicted=[27526.40890746] | 27537=expected
    18/1934 - predicted=[26815.84821082] | 26534=expected
    19/1934 - predicted=[25989.98444882] | 24261=expected
    20/1934 - predicted=[24118.32082513] | 23227=expected
    21/1934 - predicted=[23266.89283922] | 24973=expected
    22/1934 - predicted=[24704.61971551] | 24418=expected
    23/1934 - predicted=[24247.6332776] | 22060=expected
    24/1934 - predicted=[22305.97699656] | 20687=expected
    25/1934 - predicted=[21175.36393709] | 17869=expected
    26/1934 - predicted=[18854.78172553] | 12953=expected
    27/1934 - predicted=[14806.06266672] | 8370=expected
    28/1934 - predicted=[11030.23711688] | 5583=expected
    29/1934 - predicted=[8732.39685727] | 13089=expected
    30/1934 - predicted=[14916.24499477] | 21761=expected
    31/1934 - predicted=[22058.63171207] | 23254=expected
    32/1934 - predicted=[23288.10136166] | 20947=expected
    33/1934 - predicted=[21388.27373119] | 18413=expected
    34/1934 - predicted=[19301.4161057] | 18807=expected
    35/1934 - predicted=[19625.78451733] | 19844=expected
    36/1934 - predicted=[20479.70356001] | 20607=expected
    37/1934 - predicted=[21107.99141708] | 22465=expected
    38/1934 - predicted=[22638.04712135] | 23230=expected
    39/1934 - predicted=[23268.01797543] | 21378=expected
    40/1934 - predicted=[21742.87078532] | 24424=expected
    41/1934 - predicted=[24251.24578039] | 27297=expected
    42/1934 - predicted=[26617.20358469] | 26946=expected
    43/1934 - predicted=[26328.21933093] | 27630=expected
    44/1934 - predicted=[26891.58508576] | 25825=expected
    45/1934 - predicted=[25405.18970119] | 22497=expected
    46/1934 - predicted=[22664.5979686] | 15645=expected
    47/1934 - predicted=[17021.89036183] | 10506=expected
    48/1934 - predicted=[12788.76349925] | 13181=expected
    49/1934 - predicted=[14991.72481738] | 22054=expected
    50/1934 - predicted=[22299.31692445] | 23914=expected
    51/1934 - predicted=[23830.94551481] | 21837=expected
    52/1934 - predicted=[22120.61713387] | 19819=expected
    53/1934 - predicted=[20458.8202463] | 20026=expected
    54/1934 - predicted=[20629.21134965] | 20421=expected
    55/1934 - predicted=[20954.42667198] | 20762=expected
    56/1934 - predicted=[21235.17939397] | 24398=expected
    57/1934 - predicted=[24229.276575] | 27095=expected
    58/1934 - predicted=[26450.18218718] | 21702=expected
    59/1934 - predicted=[22009.33614827] | 23722=expected
    60/1934 - predicted=[23672.65491643] | 27318=expected
    61/1934 - predicted=[26633.73764281] | 29262=expected
    62/1934 - predicted=[28234.64809823] | 27264=expected
    63/1934 - predicted=[26589.45269354] | 27854=expected
    64/1934 - predicted=[27075.37924412] | 26149=expected
    65/1934 - predicted=[25671.44906442] | 19619=expected
    66/1934 - predicted=[20294.49373035] | 11489=expected
    67/1934 - predicted=[13599.42615891] | 12997=expected
    68/1934 - predicted=[14840.91239635] | 22755=expected
    69/1934 - predicted=[22876.36168033] | 24029=expected
    70/1934 - predicted=[23925.30708915] | 21590=expected
    71/1934 - predicted=[21917.15516802] | 20432=expected
    72/1934 - predicted=[20963.66723962] | 21612=expected
    73/1934 - predicted=[21935.18893299] | 22016=expected
    74/1934 - predicted=[22267.79470572] | 22456=expected
    75/1934 - predicted=[22630.04880894] | 24229=expected
    76/1934 - predicted=[24089.83887675] | 23541=expected
    77/1934 - predicted=[23523.38503491] | 21056=expected
    78/1934 - predicted=[21477.35873987] | 25119=expected
    79/1934 - predicted=[24822.57488701] | 28772=expected
    80/1934 - predicted=[27830.30755886] | 29486=expected
    81/1934 - predicted=[28418.34521128] | 27832=expected
    82/1934 - predicted=[27056.57851171] | 29732=expected
    83/1934 - predicted=[28621.13759814] | 28441=expected
    84/1934 - predicted=[27558.25325397] | 19784=expected
    85/1934 - predicted=[20430.61528233] | 12615=expected
    86/1934 - predicted=[14527.75523025] | 11458=expected
    87/1934 - predicted=[13574.36571705] | 17392=expected
    88/1934 - predicted=[18460.68254151] | 22935=expected
    89/1934 - predicted=[23024.3644344] | 22356=expected
    90/1934 - predicted=[22547.66652996] | 21345=expected
    91/1934 - predicted=[21715.29103463] | 22987=expected
    92/1934 - predicted=[23067.11752076] | 24241=expected
    93/1934 - predicted=[24099.52235647] | 24325=expected
    94/1934 - predicted=[24168.69256246] | 22452=expected
    95/1934 - predicted=[22626.67673658] | 19940=expected
    96/1934 - predicted=[20558.53524481] | 24603=expected
    97/1934 - predicted=[24397.48764417] | 29060=expected
    98/1934 - predicted=[28066.89211432] | 30174=expected
    99/1934 - predicted=[28984.23944819] | 29323=expected
    100/1934 - predicted=[28283.73447109] | 30383=expected
    101/1934 - predicted=[29156.6637397] | 29075=expected
    102/1934 - predicted=[28079.86228121] | 23120=expected
    103/1934 - predicted=[23177.07978098] | 17006=expected
    104/1934 - predicted=[18143.51721156] | 10579=expected
    105/1934 - predicted=[12851.23224416] | 11348=expected
    106/1934 - predicted=[13483.83857041] | 18678=expected
    107/1934 - predicted=[19519.50800707] | 20930=expected
    108/1934 - predicted=[21373.510204] | 21329=expected
    109/1934 - predicted=[21701.95910585] | 21301=expected
    110/1934 - predicted=[21678.87073138] | 22239=expected
    111/1934 - predicted=[22451.07780493] | 22875=expected
    112/1934 - predicted=[22974.66604103] | 22717=expected
    113/1934 - predicted=[22844.5785151] | 24965=expected
    114/1934 - predicted=[24695.29851978] | 24757=expected
    115/1934 - predicted=[24524.08124408] | 23250=expected
    116/1934 - predicted=[23283.42196256] | 28658=expected
    117/1934 - predicted=[27735.68779305] | 32371=expected
    118/1934 - predicted=[30792.91331507] | 34694=expected
    119/1934 - predicted=[32706.19457887] | 30478=expected
    120/1934 - predicted=[29234.8096978] | 28957=expected
    121/1934 - predicted=[27982.62964421] | 30508=expected
    122/1934 - predicted=[29259.83714112] | 30428=expected
    123/1934 - predicted=[29194.16912459] | 26735=expected
    124/1934 - predicted=[26153.54309707] | 22968=expected
    125/1934 - predicted=[23052.11944456] | 19122=expected
    126/1934 - predicted=[19885.63313381] | 14094=expected
    127/1934 - predicted=[15745.57615583] | 8527=expected
    128/1934 - predicted=[11160.30301953] | 8386=expected
    129/1934 - predicted=[11043.03129924] | 13690=expected
    130/1934 - predicted=[15411.30901937] | 19213=expected
    131/1934 - predicted=[19959.34392035] | 23032=expected
    132/1934 - predicted=[23103.85728264] | 25487=expected
    133/1934 - predicted=[25125.25270798] | 27521=expected
    134/1934 - predicted=[26800.07296533] | 28816=expected
    135/1934 - predicted=[27866.49222425] | 28028=expected
    136/1934 - predicted=[27217.74423718] | 28775=expected
    137/1934 - predicted=[27832.95556244] | 27264=expected
    138/1934 - predicted=[26588.8461935] | 29616=expected
    139/1934 - predicted=[28525.66794666] | 33060=expected
    140/1934 - predicted=[31362.04928487] | 34231=expected
    141/1934 - predicted=[32326.9275003] | 29148=expected
    142/1934 - predicted=[28140.91099856] | 28500=expected
    143/1934 - predicted=[27607.41586817] | 30849=expected
    144/1934 - predicted=[29541.98639772] | 29801=expected
    145/1934 - predicted=[28679.10893411] | 25850=expected
    146/1934 - predicted=[25425.54737603] | 24164=expected
    147/1934 - predicted=[24037.227339] | 20390=expected
    148/1934 - predicted=[20929.52530649] | 14768=expected
    149/1934 - predicted=[16299.78104567] | 9204=expected
    150/1934 - predicted=[11716.48818674] | 5325=expected
    151/1934 - predicted=[8519.16632828] | 7611=expected
    152/1934 - predicted=[10401.48242556] | 11040=expected
    153/1934 - predicted=[13225.99608147] | 15815=expected
    154/1934 - predicted=[17159.41858905] | 21363=expected
    155/1934 - predicted=[21729.12153408] | 24111=expected
    156/1934 - predicted=[23992.39765694] | 27092=expected
    157/1934 - predicted=[26447.61577518] | 26670=expected
    158/1934 - predicted=[26100.11053766] | 27100=expected
    159/1934 - predicted=[26454.33415566] | 25862=expected
    160/1934 - predicted=[25434.7397668] | 26290=expected
    161/1934 - predicted=[25787.29687164] | 26369=expected
    162/1934 - predicted=[25852.41545208] | 26711=expected
    163/1934 - predicted=[26134.1544329] | 24583=expected
    164/1934 - predicted=[24381.51292489] | 22353=expected
    165/1934 - predicted=[22544.85667541] | 20628=expected
    166/1934 - predicted=[21124.08690658] | 17138=expected
    167/1934 - predicted=[18249.49671604] | 13244=expected
    168/1934 - predicted=[15041.66670413] | 7846=expected
    169/1934 - predicted=[10593.5449096] | 13178=expected
    170/1934 - predicted=[14986.38734475] | 22999=expected
    171/1934 - predicted=[23076.18379322] | 25405=expected
    172/1934 - predicted=[25057.78585656] | 23185=expected
    173/1934 - predicted=[23229.40158614] | 21055=expected
    174/1934 - predicted=[21475.11515305] | 22146=expected
    175/1934 - predicted=[22373.6352772] | 22751=expected
    176/1934 - predicted=[22871.89580102] | 23743=expected
    177/1934 - predicted=[23688.89952295] | 25898=expected
    178/1934 - predicted=[25463.77064908] | 25976=expected
    179/1934 - predicted=[25528.05568244] | 24503=expected
    180/1934 - predicted=[24314.92064083] | 28773=expected
    181/1934 - predicted=[27831.75366551] | 32217=expected
    182/1934 - predicted=[30668.65149492] | 31358=expected
    183/1934 - predicted=[29961.35378713] | 28898=expected
    184/1934 - predicted=[27935.22709268] | 26765=expected
    185/1934 - predicted=[26178.45611892] | 22241=expected
    186/1934 - predicted=[22452.42778869] | 14735=expected
    187/1934 - predicted=[16270.26606915] | 9262=expected
    188/1934 - predicted=[11761.14052015] | 12926=expected
    189/1934 - predicted=[14779.26783972] | 23273=expected
    190/1934 - predicted=[23301.8551151] | 27014=expected
    191/1934 - predicted=[26382.77991959] | 25138=expected
    192/1934 - predicted=[24837.83211789] | 23461=expected
    193/1934 - predicted=[23456.76477105] | 23237=expected
    194/1934 - predicted=[23272.29058835] | 24042=expected
    195/1934 - predicted=[23935.24264169] | 24562=expected
    196/1934 - predicted=[24363.49713099] | 26953=expected
    197/1934 - predicted=[26332.63122559] | 25387=expected
    198/1934 - predicted=[25042.99644257] | 22391=expected
    199/1934 - predicted=[22575.6888462] | 26186=expected
    200/1934 - predicted=[25700.98743392] | 28633=expected
    201/1934 - predicted=[27716.28100772] | 29495=expected
    202/1934 - predicted=[28426.33854587] | 29760=expected
    203/1934 - predicted=[28644.756621] | 26903=expected
    204/1934 - predicted=[26291.85677356] | 19191=expected
    205/1934 - predicted=[19940.81213325] | 11715=expected
    206/1934 - predicted=[13783.51409691] | 13288=expected
    207/1934 - predicted=[15078.71554252] | 24387=expected
    208/1934 - predicted=[24219.323465] | 27219=expected
    209/1934 - predicted=[26551.33264787] | 25454=expected
    210/1934 - predicted=[25098.003435] | 23906=expected
    211/1934 - predicted=[23823.35407457] | 24507=expected
    212/1934 - predicted=[24318.24506602] | 25619=expected
    213/1934 - predicted=[25233.92391756] | 25613=expected
    214/1934 - predicted=[25229.02054095] | 27710=expected
    215/1934 - predicted=[26955.83642364] | 27660=expected
    216/1934 - predicted=[26914.75153497] | 24464=expected
    217/1934 - predicted=[24283.05808236] | 33523=expected
    218/1934 - predicted=[31742.70175814] | 29854=expected
    219/1934 - predicted=[28721.44940079] | 21946=expected
    220/1934 - predicted=[22210.04689022] | 13607=expected
    221/1934 - predicted=[15343.88388264] | 13533=expected
    222/1934 - predicted=[15282.53222097] | 24215=expected
    223/1934 - predicted=[24077.83639181] | 27066=expected
    224/1934 - predicted=[26425.00032463] | 24841=expected
    225/1934 - predicted=[24593.26506935] | 23854=expected
    226/1934 - predicted=[23780.72546128] | 23958=expected
    227/1934 - predicted=[23866.35122978] | 25127=expected
    228/1934 - predicted=[24828.75440573] | 24840=expected
    229/1934 - predicted=[24592.50413054] | 26888=expected
    230/1934 - predicted=[26278.58693707] | 26546=expected
    231/1934 - predicted=[25997.08848552] | 23092=expected
    232/1934 - predicted=[23153.56896283] | 27514=expected
    233/1934 - predicted=[26793.9925568] | 19185=expected
    234/1934 - predicted=[19937.37301662] | 12210=expected
    235/1934 - predicted=[14194.88454999] | 7947=expected
    236/1934 - predicted=[10683.550188] | 5531=expected
    237/1934 - predicted=[8691.94122469] | 13144=expected
    238/1934 - predicted=[14962.02576946] | 23943=expected
    239/1934 - predicted=[23853.26737823] | 25974=expected
    240/1934 - predicted=[25525.24667948] | 24544=expected
    241/1934 - predicted=[24348.07063231] | 23369=expected
    242/1934 - predicted=[23380.80291546] | 24015=expected
    243/1934 - predicted=[23912.60192368] | 24959=expected
    244/1934 - predicted=[24689.73200862] | 24716=expected
    245/1934 - predicted=[24489.71299866] | 27038=expected
    246/1934 - predicted=[26401.27050174] | 25991=expected
    247/1934 - predicted=[25539.40409167] | 23498=expected
    248/1934 - predicted=[23487.14756565] | 29052=expected
    249/1934 - predicted=[28059.29152537] | 33767=expected
    250/1934 - predicted=[31941.33519333] | 30350=expected
    251/1934 - predicted=[29128.23871248] | 29939=expected
    252/1934 - predicted=[28790.0485347] | 30344=expected
    253/1934 - predicted=[29123.67117518] | 26566=expected
    254/1934 - predicted=[26013.41152438] | 24621=expected
    255/1934 - predicted=[24412.2581961] | 20867=expected
    256/1934 - predicted=[21321.88832368] | 17616=expected
    257/1934 - predicted=[18645.46350524] | 12514=expected
    258/1934 - predicted=[14444.63549566] | 8320=expected
    259/1934 - predicted=[10990.07900415] | 8002=expected
    260/1934 - predicted=[10726.96844435] | 12863=expected
    261/1934 - predicted=[14730.06668674] | 19178=expected
    262/1934 - predicted=[19930.02095145] | 25017=expected
    263/1934 - predicted=[24737.37639756] | 26219=expected
    264/1934 - predicted=[25727.02566739] | 26787=expected
    265/1934 - predicted=[26194.72405387] | 27525=expected
    266/1934 - predicted=[26802.40986318] | 27758=expected
    267/1934 - predicted=[26994.3336963] | 28181=expected
    268/1934 - predicted=[27342.70503167] | 26316=expected
    269/1934 - predicted=[25807.23976289] | 30439=expected
    270/1934 - predicted=[29202.00206005] | 33721=expected
    271/1934 - predicted=[31904.81884019] | 35601=expected
    272/1934 - predicted=[33453.64456898] | 30721=expected
    273/1934 - predicted=[29435.04089544] | 30509=expected
    274/1934 - predicted=[29260.67581162] | 30370=expected
    275/1934 - predicted=[29146.41489294] | 29951=expected
    276/1934 - predicted=[28801.56263709] | 26491=expected
    277/1934 - predicted=[25952.5217646] | 23474=expected
    278/1934 - predicted=[23468.34094837] | 19149=expected
    279/1934 - predicted=[19907.14294642] | 14345=expected
    280/1934 - predicted=[15951.14789942] | 8945=expected
    281/1934 - predicted=[11503.09128222] | 7076=expected
    282/1934 - predicted=[9962.12619863] | 10926=expected
    283/1934 - predicted=[13133.12013851] | 16077=expected
    284/1934 - predicted=[17375.68922067] | 21729=expected
    285/1934 - predicted=[22030.3328758] | 24534=expected
    286/1934 - predicted=[24340.21160698] | 25488=expected
    287/1934 - predicted=[25125.84366548] | 24521=expected
    288/1934 - predicted=[24329.55559425] | 24484=expected
    289/1934 - predicted=[24299.10350998] | 22957=expected
    290/1934 - predicted=[23041.64858435] | 24027=expected
    291/1934 - predicted=[23922.77497333] | 25057=expected
    292/1934 - predicted=[24770.97989511] | 25167=expected
    293/1934 - predicted=[24861.59103369] | 22828=expected
    294/1934 - predicted=[22935.47521237] | 20484=expected
    295/1934 - predicted=[21005.20892166] | 16792=expected
    296/1934 - predicted=[17964.71958622] | 13021=expected
    297/1934 - predicted=[14858.66689044] | 7053=expected
    298/1934 - predicted=[9941.56002565] | 12902=expected
    299/1934 - predicted=[14759.73168146] | 21936=expected
    300/1934 - predicted=[22200.17078732] | 24822=expected
    301/1934 - predicted=[24576.73711069] | 22365=expected
    302/1934 - predicted=[22553.4584651] | 20505=expected
    303/1934 - predicted=[21021.75563556] | 20267=expected
    304/1934 - predicted=[20825.7102676] | 20722=expected
    305/1934 - predicted=[21200.34671084] | 21407=expected
    306/1934 - predicted=[21764.39545039] | 23825=expected
    307/1934 - predicted=[23755.55499077] | 24692=expected
    308/1934 - predicted=[24469.5204255] | 23102=expected
    309/1934 - predicted=[23160.20436772] | 27190=expected
    310/1934 - predicted=[26526.57524603] | 31560=expected
    311/1934 - predicted=[30125.46132482] | 29607=expected
    312/1934 - predicted=[28517.24206234] | 27320=expected
    313/1934 - predicted=[26633.95484694] | 24622=expected
    314/1934 - predicted=[24412.22893007] | 21603=expected
    315/1934 - predicted=[21926.18002209] | 14308=expected
    316/1934 - predicted=[15918.73737382] | 8982=expected
    317/1934 - predicted=[11531.31559675] | 12605=expected
    318/1934 - predicted=[14515.19537267] | 23008=expected
    319/1934 - predicted=[23082.60914099] | 26026=expected
    320/1934 - predicted=[25567.7013533] | 24053=expected
    321/1934 - predicted=[23943.12001224] | 22593=expected
    322/1934 - predicted=[22740.93811463] | 22304=expected
    323/1934 - predicted=[22502.95637878] | 23080=expected
    324/1934 - predicted=[23141.91225219] | 22992=expected
    325/1934 - predicted=[23069.44588321] | 25422=expected
    326/1934 - predicted=[25070.3421694] | 26019=expected
    327/1934 - predicted=[25561.96015182] | 23385=expected
    328/1934 - predicted=[23393.1143891] | 28893=expected
    329/1934 - predicted=[27928.45863589] | 32813=expected
    330/1934 - predicted=[31156.68649517] | 32029=expected
    331/1934 - predicted=[30511.34862685] | 31364=expected
    332/1934 - predicted=[29963.96844885] | 26188=expected
    333/1934 - predicted=[25701.67482017] | 18824=expected
    334/1934 - predicted=[19638.11668102] | 13186=expected
    335/1934 - predicted=[14995.26193374] | 13004=expected
    336/1934 - predicted=[14844.91953275] | 23930=expected
    337/1934 - predicted=[23841.97329885] | 26555=expected
    338/1934 - predicted=[26003.241313] | 25207=expected
    339/1934 - predicted=[24893.42578333] | 22665=expected
    340/1934 - predicted=[22800.54474993] | 23412=expected
    341/1934 - predicted=[23415.55839017] | 24497=expected
    342/1934 - predicted=[24308.86749074] | 23839=expected
    343/1934 - predicted=[23767.13495655] | 25400=expected
    344/1934 - predicted=[25052.35548303] | 25561=expected
    345/1934 - predicted=[25184.94499509] | 23191=expected
    346/1934 - predicted=[23233.69107335] | 28186=expected
    347/1934 - predicted=[27346.1736647] | 31789=expected
    348/1934 - predicted=[30312.93152189] | 31059=expected
    349/1934 - predicted=[29712.08528466] | 27599=expected
    350/1934 - predicted=[26863.27741332] | 20311=expected
    351/1934 - predicted=[20862.98869057] | 12290=expected
    352/1934 - predicted=[14258.84100519] | 12981=expected
    353/1934 - predicted=[14827.36896546] | 23982=expected
    354/1934 - predicted=[23884.87967816] | 27154=expected
    355/1934 - predicted=[26496.13883269] | 25076=expected
    356/1934 - predicted=[24785.53639926] | 23483=expected
    357/1934 - predicted=[23474.18696679] | 23153=expected
    358/1934 - predicted=[23202.52911373] | 25001=expected
    359/1934 - predicted=[24723.8110383] | 25410=expected
    360/1934 - predicted=[25060.53129105] | 27544=expected
    361/1934 - predicted=[26817.31860713] | 27400=expected
    362/1934 - predicted=[26698.85407624] | 25384=expected
    363/1934 - predicted=[25039.29017468] | 27217=expected
    364/1934 - predicted=[26548.29201046] | 17608=expected
    365/1934 - predicted=[18638.34072426] | 11238=expected
    366/1934 - predicted=[13393.89247023] | 5233=expected
    367/1934 - predicted=[8447.52718849] | 12832=expected
    368/1934 - predicted=[14705.33966926] | 22877=expected
    369/1934 - predicted=[22974.90046037] | 26778=expected
    370/1934 - predicted=[26185.92296444] | 25483=expected
    371/1934 - predicted=[25120.0154678] | 23375=expected
    372/1934 - predicted=[23384.89726791] | 23799=expected
    373/1934 - predicted=[23733.89980381] | 24764=expected
    374/1934 - predicted=[24528.21811905] | 24604=expected
    375/1934 - predicted=[24396.53952463] | 28535=expected
    376/1934 - predicted=[27632.28470545] | 28239=expected
    377/1934 - predicted=[27388.74255028] | 24112=expected
    378/1934 - predicted=[23991.72913856] | 30410=expected
    379/1934 - predicted=[29175.73329453] | 30503=expected
    380/1934 - predicted=[29252.48758241] | 32278=expected
    381/1934 - predicted=[30713.93596126] | 30482=expected
    382/1934 - predicted=[29235.65171371] | 26003=expected
    383/1934 - predicted=[25548.74685796] | 22713=expected
    384/1934 - predicted=[22840.71239036] | 18667=expected
    385/1934 - predicted=[19510.35818503] | 12950=expected
    386/1934 - predicted=[14804.0310318] | 7998=expected
    387/1934 - predicted=[10725.92726452] | 5980=expected
    388/1934 - predicted=[9062.45013886] | 9015=expected
    389/1934 - predicted=[11561.1106287] | 14436=expected
    390/1934 - predicted=[16024.9735905] | 20997=expected
    391/1934 - predicted=[21426.78563374] | 24075=expected
    392/1934 - predicted=[23960.71236638] | 26262=expected
    393/1934 - predicted=[25761.16114204] | 27552=expected
    394/1934 - predicted=[26823.22457322] | 28218=expected
    395/1934 - predicted=[27371.61392997] | 27719=expected
    396/1934 - predicted=[26960.89200154] | 28108=expected
    397/1934 - predicted=[27281.24284957] | 26061=expected
    398/1934 - predicted=[25596.05545127] | 29315=expected
    399/1934 - predicted=[28275.07857695] | 32529=expected
    400/1934 - predicted=[30921.51438527] | 33877=expected
    401/1934 - predicted=[32031.89828155] | 28358=expected
    402/1934 - predicted=[27487.69555851] | 27680=expected
    403/1934 - predicted=[26929.5835832] | 31622=expected
    404/1934 - predicted=[30175.32913181] | 32421=expected
    405/1934 - predicted=[30833.53877183] | 28351=expected
    406/1934 - predicted=[27482.46594015] | 25091=expected
    407/1934 - predicted=[24798.48508251] | 20643=expected
    408/1934 - predicted=[21136.48079759] | 14868=expected
    409/1934 - predicted=[16381.6924348] | 8975=expected
    410/1934 - predicted=[11528.38032138] | 6513=expected
    411/1934 - predicted=[9499.11864684] | 12634=expected
    412/1934 - predicted=[14540.45660811] | 18203=expected
    413/1934 - predicted=[19126.34290942] | 23578=expected
    414/1934 - predicted=[23551.94418943] | 27001=expected
    415/1934 - predicted=[26370.27409707] | 25258=expected
    416/1934 - predicted=[24935.22005444] | 24661=expected
    417/1934 - predicted=[24443.71066487] | 23610=expected
    418/1934 - predicted=[23578.39532285] | 23279=expected
    419/1934 - predicted=[23305.8718498] | 22976=expected
    420/1934 - predicted=[23056.39681982] | 25878=expected
    421/1934 - predicted=[25445.72382368] | 27123=expected
    422/1934 - predicted=[26470.84308987] | 24792=expected
    423/1934 - predicted=[24551.66782141] | 21763=expected
    424/1934 - predicted=[22057.80975368] | 21312=expected
    425/1934 - predicted=[21686.45753238] | 18966=expected
    426/1934 - predicted=[19754.84562716] | 16290=expected
    427/1934 - predicted=[17551.35098396] | 10156=expected
    428/1934 - predicted=[12499.69396268] | 9039=expected
    429/1934 - predicted=[11578.73232023] | 13927=expected
    430/1934 - predicted=[15604.29374508] | 18927=expected
    431/1934 - predicted=[19721.65624559] | 19725=expected
    432/1934 - predicted=[20378.67083449] | 21165=expected
    433/1934 - predicted=[21564.3381067] | 21823=expected
    434/1934 - predicted=[22106.10803879] | 23835=expected
    435/1934 - predicted=[23762.77944704] | 23587=expected
    436/1934 - predicted=[23558.58149268] | 23162=expected
    437/1934 - predicted=[23208.63712626] | 22846=expected
    438/1934 - predicted=[22948.43722447] | 26392=expected
    439/1934 - predicted=[25868.21197456] | 29539=expected
    440/1934 - predicted=[28459.59989379] | 27108=expected
    441/1934 - predicted=[26457.92187335] | 23970=expected
    442/1934 - predicted=[23874.12582383] | 22826=expected
    443/1934 - predicted=[22932.17457226] | 20223=expected
    444/1934 - predicted=[20788.87023607] | 14654=expected
    445/1934 - predicted=[16203.08869406] | 9761=expected
    446/1934 - predicted=[12172.81489716] | 13289=expected
    447/1934 - predicted=[15078.15762116] | 23888=expected
    448/1934 - predicted=[23806.03380014] | 26859=expected
    449/1934 - predicted=[26252.22660759] | 25234=expected
    450/1934 - predicted=[24914.32037281] | 23173=expected
    451/1934 - predicted=[23217.42760804] | 23700=expected
    452/1934 - predicted=[23651.3260526] | 24199=expected
    453/1934 - predicted=[24062.17939667] | 24832=expected
    454/1934 - predicted=[24583.36890374] | 26765=expected
    455/1934 - predicted=[26174.93245774] | 27872=expected
    456/1934 - predicted=[27086.46944655] | 29161=expected
    457/1934 - predicted=[28147.92278985] | 31001=expected
    458/1934 - predicted=[29663.19796457] | 26499=expected
    459/1934 - predicted=[25956.28116491] | 18784=expected
    460/1934 - predicted=[19604.25383924] | 11262=expected
    461/1934 - predicted=[13410.42127675] | 12767=expected
    462/1934 - predicted=[14649.29553285] | 23823=expected
    463/1934 - predicted=[23752.54828481] | 28183=expected
    464/1934 - predicted=[27341.9497669] | 25902=expected
    465/1934 - predicted=[25464.15255628] | 23790=expected
    466/1934 - predicted=[23725.49416022] | 24599=expected
    467/1934 - predicted=[24391.50129349] | 25480=expected
    468/1934 - predicted=[25116.79729536] | 25014=expected
    469/1934 - predicted=[24733.19834041] | 27005=expected
    470/1934 - predicted=[26372.31573339] | 26779=expected
    471/1934 - predicted=[26186.32379872] | 24902=expected
    472/1934 - predicted=[24641.12850547] | 32241=expected
    473/1934 - predicted=[30683.07385509] | 31904=expected
    474/1934 - predicted=[30405.90077645] | 30618=expected
    475/1934 - predicted=[29347.32282328] | 28622=expected
    476/1934 - predicted=[27704.13390473] | 23746=expected
    477/1934 - predicted=[23689.94114693] | 16201=expected
    478/1934 - predicted=[17478.62914843] | 8143=expected
    479/1934 - predicted=[10843.36985695] | 13845=expected
    480/1934 - predicted=[15538.43361404] | 25338=expected
    481/1934 - predicted=[24999.83825748] | 29719=expected
    482/1934 - predicted=[28606.08388037] | 27643=expected
    483/1934 - predicted=[26897.29943564] | 25296=expected
    484/1934 - predicted=[24965.44827989] | 24920=expected
    485/1934 - predicted=[24655.98199214] | 25797=expected
    486/1934 - predicted=[25377.89223993] | 25586=expected
    487/1934 - predicted=[25204.24942016] | 28107=expected
    488/1934 - predicted=[27279.43162819] | 26841=expected
    489/1934 - predicted=[26237.40256584] | 23399=expected
    490/1934 - predicted=[23404.22805395] | 28058=expected
    491/1934 - predicted=[27239.14418123] | 20007=expected
    492/1934 - predicted=[20612.44446192] | 12675=expected
    493/1934 - predicted=[14577.21332649] | 7777=expected
    494/1934 - predicted=[10543.77563951] | 12779=expected
    495/1934 - predicted=[14661.81150696] | 23430=expected
    496/1934 - predicted=[23429.18998949] | 26718=expected
    497/1934 - predicted=[26135.31184566] | 24946=expected
    498/1934 - predicted=[24676.94531135] | 23046=expected
    499/1934 - predicted=[23113.22477941] | 23982=expected
    500/1934 - predicted=[23883.56564805] | 24867=expected
    501/1934 - predicted=[24611.94785131] | 24321=expected
    502/1934 - predicted=[24162.6004256] | 27520=expected
    503/1934 - predicted=[26795.47311458] | 27151=expected
    504/1934 - predicted=[26491.84920947] | 25085=expected
    505/1934 - predicted=[24791.52061688] | 29475=expected
    506/1934 - predicted=[28404.66780515] | 30646=expected
    507/1934 - predicted=[29368.67085872] | 30330=expected
    508/1934 - predicted=[29108.77021529] | 31541=expected
    509/1934 - predicted=[30105.80098869] | 31528=expected
    510/1934 - predicted=[30095.36602544] | 28033=expected
    511/1934 - predicted=[27218.63626551] | 23214=expected
    512/1934 - predicted=[23252.3036505] | 20732=expected
    513/1934 - predicted=[21209.48754928] | 13428=expected
    514/1934 - predicted=[15197.572821] | 8103=expected
    515/1934 - predicted=[10812.92019511] | 6137=expected
    516/1934 - predicted=[9192.4928635] | 8799=expected
    517/1934 - predicted=[11383.67064756] | 14482=expected
    518/1934 - predicted=[16062.85879436] | 20815=expected
    519/1934 - predicted=[21276.42310289] | 25244=expected
    520/1934 - predicted=[24922.18323748] | 27111=expected
    521/1934 - predicted=[26459.06610533] | 30140=expected
    522/1934 - predicted=[28952.61408088] | 30161=expected
    523/1934 - predicted=[28970.08480478] | 29082=expected
    524/1934 - predicted=[28081.96931348] | 29812=expected
    525/1934 - predicted=[28683.0791307] | 28190=expected
    526/1934 - predicted=[27347.91014569] | 29883=expected
    527/1934 - predicted=[28741.78185376] | 33525=expected
    528/1934 - predicted=[31740.51196158] | 35630=expected
    529/1934 - predicted=[33474.34609948] | 28660=expected
    530/1934 - predicted=[27735.51023813] | 28183=expected
    531/1934 - predicted=[27342.92350173] | 30960=expected
    532/1934 - predicted=[29629.3292058] | 31234=expected
    533/1934 - predicted=[29855.15759166] | 28861=expected
    534/1934 - predicted=[27901.56089116] | 25661=expected
    535/1934 - predicted=[25267.12891308] | 21720=expected
    536/1934 - predicted=[22022.72966829] | 15851=expected
    537/1934 - predicted=[17190.96327658] | 9845=expected
    538/1934 - predicted=[12245.24431658] | 7546=expected
    539/1934 - predicted=[10350.6987381] | 11049=expected
    540/1934 - predicted=[13235.14381658] | 16920=expected
    541/1934 - predicted=[18069.67261053] | 23614=expected
    542/1934 - predicted=[23581.07841102] | 27425=expected
    543/1934 - predicted=[26718.68023404] | 29009=expected
    544/1934 - predicted=[28022.92196834] | 28916=expected
    545/1934 - predicted=[27946.48020139] | 29019=expected
    546/1934 - predicted=[28031.41163188] | 27220=expected
    547/1934 - predicted=[26550.30433621] | 26687=expected
    548/1934 - predicted=[26111.53449303] | 27275=expected
    549/1934 - predicted=[26595.72098587] | 28023=expected
    550/1934 - predicted=[27211.66571726] | 24168=expected
    551/1934 - predicted=[24037.75725475] | 22185=expected
    552/1934 - predicted=[22405.13382894] | 19055=expected
    553/1934 - predicted=[19828.11489608] | 16777=expected
    554/1934 - predicted=[17952.39239914] | 13348=expected
    555/1934 - predicted=[15128.60840544] | 8130=expected
    556/1934 - predicted=[10830.46081693] | 12765=expected
    557/1934 - predicted=[14647.54928555] | 23118=expected
    558/1934 - predicted=[23172.54545736] | 28068=expected
    559/1934 - predicted=[27247.92985078] | 26488=expected
    560/1934 - predicted=[25947.15414547] | 22765=expected
    561/1934 - predicted=[22882.04369891] | 22552=expected
    562/1934 - predicted=[22706.67222093] | 23467=expected
    563/1934 - predicted=[23459.97064724] | 24048=expected
    564/1934 - predicted=[23938.30319927] | 26449=expected
    565/1934 - predicted=[25915.04101297] | 27372=expected
    566/1934 - predicted=[26675.01198421] | 25930=expected
    567/1934 - predicted=[25487.86414138] | 29692=expected
    568/1934 - predicted=[28585.23329625] | 33787=expected
    569/1934 - predicted=[31957.27776195] | 29971=expected
    570/1934 - predicted=[28815.30495336] | 29002=expected
    571/1934 - predicted=[28017.61253639] | 25467=expected
    572/1934 - predicted=[25107.18554728] | 18654=expected
    573/1934 - predicted=[19498.10259611] | 10900=expected
    574/1934 - predicted=[13113.49210708] | 13417=expected
    575/1934 - predicted=[15185.7254569] | 24724=expected
    576/1934 - predicted=[24494.94467984] | 28460=expected
    577/1934 - predicted=[27570.49739084] | 26224=expected
    578/1934 - predicted=[25729.84394841] | 24009=expected
    579/1934 - predicted=[23906.48764894] | 24009=expected
    580/1934 - predicted=[23906.49653899] | 24383=expected
    581/1934 - predicted=[24214.38118388] | 24291=expected
    582/1934 - predicted=[24138.66160775] | 26148=expected
    583/1934 - predicted=[25667.35867156] | 27115=expected
    584/1934 - predicted=[26463.45371052] | 24137=expected
    585/1934 - predicted=[24011.9980071] | 28967=expected
    586/1934 - predicted=[27988.05584194] | 28525=expected
    587/1934 - predicted=[27624.30868046] | 20093=expected
    588/1934 - predicted=[20683.33733725] | 11198=expected
    589/1934 - predicted=[13360.83890939] | 13166=expected
    590/1934 - predicted=[14980.66037135] | 24846=expected
    591/1934 - predicted=[24595.21523597] | 28259=expected
    592/1934 - predicted=[27404.33685967] | 25822=expected
    593/1934 - predicted=[25398.59705556] | 24036=expected
    594/1934 - predicted=[23928.67333106] | 24374=expected
    595/1934 - predicted=[24206.87031475] | 24713=expected
    596/1934 - predicted=[24485.89664951] | 25357=expected
    597/1934 - predicted=[25015.95803958] | 27088=expected
    598/1934 - predicted=[26440.69522925] | 27048=expected
    599/1934 - predicted=[26407.84104815] | 24707=expected
    600/1934 - predicted=[24481.12120852] | 29779=expected
    601/1934 - predicted=[28655.67570723] | 30748=expected
    602/1934 - predicted=[29453.45295019] | 21843=expected
    603/1934 - predicted=[22124.23784023] | 13104=expected
    604/1934 - predicted=[14931.87783918] | 7934=expected
    605/1934 - predicted=[10675.13074881] | 13527=expected
    606/1934 - predicted=[15279.21767178] | 24643=expected
    607/1934 - predicted=[24427.95228953] | 27931=expected
    608/1934 - predicted=[27133.75338824] | 26111=expected
    609/1934 - predicted=[25636.08264194] | 23457=expected
    610/1934 - predicted=[23452.10004568] | 24422=expected
    611/1934 - predicted=[24246.20764199] | 25033=expected
    612/1934 - predicted=[24749.02211515] | 25208=expected
    613/1934 - predicted=[24893.05780276] | 27691=expected
    614/1934 - predicted=[26936.40394308] | 26887=expected
    615/1934 - predicted=[26274.84209579] | 23892=expected
    616/1934 - predicted=[23810.24976174] | 27334=expected
    617/1934 - predicted=[26642.70837422] | 19422=expected
    618/1934 - predicted=[20132.08094429] | 11736=expected
    619/1934 - predicted=[13806.88811108] | 7700=expected
    620/1934 - predicted=[10483.79346974] | 13039=expected
    621/1934 - predicted=[14878.2579938] | 23462=expected
    622/1934 - predicted=[23455.8243232] | 27051=expected
    623/1934 - predicted=[26408.97065436] | 26114=expected
    624/1934 - predicted=[25638.02811013] | 23898=expected
    625/1934 - predicted=[23814.67258657] | 24819=expected
    626/1934 - predicted=[24572.50190061] | 24804=expected
    627/1934 - predicted=[24560.1813039] | 24993=expected
    628/1934 - predicted=[24715.71764731] | 27817=expected
    629/1934 - predicted=[27039.43371817] | 26477=expected
    630/1934 - predicted=[25936.89307978] | 23505=expected
    631/1934 - predicted=[23491.4894553] | 31796=expected
    632/1934 - predicted=[30313.49066162] | 30208=expected
    633/1934 - predicted=[29006.9706001] | 32254=expected
    634/1934 - predicted=[30690.84573877] | 32238=expected
    635/1934 - predicted=[30677.98866529] | 27726=expected
    636/1934 - predicted=[26965.16881091] | 22392=expected
    637/1934 - predicted=[22576.27590877] | 18132=expected
    638/1934 - predicted=[19071.07973003] | 12794=expected
    639/1934 - predicted=[14678.32389842] | 8277=expected
    640/1934 - predicted=[10959.81565215] | 5703=expected
    641/1934 - predicted=[8839.2407985] | 9553=expected
    642/1934 - predicted=[12008.05411135] | 16299=expected
    643/1934 - predicted=[17560.78585416] | 21807=expected
    644/1934 - predicted=[22093.65715731] | 24852=expected
    645/1934 - predicted=[24599.42843021] | 27375=expected
    646/1934 - predicted=[26675.69564836] | 29121=expected
    647/1934 - predicted=[28112.65890516] | 30521=expected
    648/1934 - predicted=[29265.00315821] | 28817=expected
    649/1934 - predicted=[27862.76510762] | 29672=expected
    650/1934 - predicted=[28566.55993167] | 27041=expected
    651/1934 - predicted=[26401.37859386] | 30376=expected
    652/1934 - predicted=[29146.12850265] | 33788=expected
    653/1934 - predicted=[31954.70400537] | 35630=expected
    654/1934 - predicted=[33471.5424508] | 28039=expected
    655/1934 - predicted=[27223.31445054] | 26846=expected
    656/1934 - predicted=[26241.56053206] | 31348=expected
    657/1934 - predicted=[29946.8568451] | 32539=expected
    658/1934 - predicted=[30927.4444744] | 28804=expected
    659/1934 - predicted=[27853.40697441] | 24576=expected
    660/1934 - predicted=[24373.79669846] | 20172=expected
    661/1934 - predicted=[20749.43589427] | 14725=expected
    662/1934 - predicted=[16266.41169587] | 9279=expected
    663/1934 - predicted=[11782.97517299] | 6756=expected
    664/1934 - predicted=[9704.39456058] | 11404=expected
    665/1934 - predicted=[13530.82628187] | 16797=expected
    666/1934 - predicted=[17970.26524798] | 22583=expected
    667/1934 - predicted=[22732.62068941] | 24949=expected
    668/1934 - predicted=[24679.9384728] | 27187=expected
    669/1934 - predicted=[26521.96114314] | 27837=expected
    670/1934 - predicted=[27057.0336122] | 27705=expected
    671/1934 - predicted=[26948.47536321] | 27555=expected
    672/1934 - predicted=[26825.09545883] | 26503=expected
    673/1934 - predicted=[25959.28495748] | 26861=expected
    674/1934 - predicted=[26254.00343925] | 27762=expected
    675/1934 - predicted=[26995.67516448] | 24808=expected
    676/1934 - predicted=[24564.35209718] | 23108=expected
    677/1934 - predicted=[23165.16684447] | 20727=expected
    678/1934 - predicted=[21205.45180517] | 17040=expected
    679/1934 - predicted=[18170.67950599] | 12120=expected
    680/1934 - predicted=[14120.40977603] | 7778=expected
    681/1934 - predicted=[10544.57126719] | 12493=expected
    682/1934 - predicted=[14426.38109606] | 22295=expected
    683/1934 - predicted=[22495.28914985] | 25587=expected
    684/1934 - predicted=[25204.80384359] | 23612=expected
    685/1934 - predicted=[23579.28470589] | 21437=expected
    686/1934 - predicted=[21789.13585265] | 21303=expected
    687/1934 - predicted=[21678.81267073] | 23158=expected
    688/1934 - predicted=[23205.55727962] | 23595=expected
    689/1934 - predicted=[23565.22827107] | 26681=expected
    690/1934 - predicted=[26105.18021591] | 26395=expected
    691/1934 - predicted=[25869.84023796] | 24583=expected
    692/1934 - predicted=[24378.4996632] | 28929=expected
    693/1934 - predicted=[27955.54148499] | 30083=expected
    694/1934 - predicted=[28905.54715285] | 27751=expected
    695/1934 - predicted=[26986.1873475] | 26841=expected
    696/1934 - predicted=[26237.26135282] | 23817=expected
    697/1934 - predicted=[23748.36219538] | 15201=expected
    698/1934 - predicted=[16656.99047462] | 9110=expected
    699/1934 - predicted=[11642.4025332] | 13067=expected
    700/1934 - predicted=[14899.64384807] | 25854=expected
    701/1934 - predicted=[25424.16234761] | 27838=expected
    702/1934 - predicted=[27056.95682449] | 25451=expected
    703/1934 - predicted=[25092.61635106] | 22763=expected
    704/1934 - predicted=[22880.58389689] | 22528=expected
    705/1934 - predicted=[22687.18350517] | 24700=expected
    706/1934 - predicted=[24474.58229909] | 26653=expected
    707/1934 - predicted=[26081.80192951] | 26456=expected
    708/1934 - predicted=[25919.73800443] | 27403=expected
    709/1934 - predicted=[26699.13269414] | 23340=expected
    710/1934 - predicted=[23355.56905492] | 27792=expected
    711/1934 - predicted=[27019.23125124] | 32428=expected
    712/1934 - predicted=[30834.68473112] | 31178=expected
    713/1934 - predicted=[29806.15529627] | 30539=expected
    714/1934 - predicted=[29280.46070798] | 27514=expected
    715/1934 - predicted=[26791.00242349] | 20120=expected
    716/1934 - predicted=[20706.27433173] | 12398=expected
    717/1934 - predicted=[14351.23850591] | 7091=expected
    718/1934 - predicted=[9981.76635587] | 12934=expected
    719/1934 - predicted=[14791.44779442] | 24152=expected
    720/1934 - predicted=[24023.60029627] | 27671=expected
    721/1934 - predicted=[26919.26728356] | 26016=expected
    722/1934 - predicted=[25557.47948616] | 24363=expected
    723/1934 - predicted=[24197.3326219] | 25056=expected
    724/1934 - predicted=[24767.5851241] | 25479=expected
    725/1934 - predicted=[25115.68052416] | 25140=expected
    726/1934 - predicted=[24836.76362198] | 27256=expected
    727/1934 - predicted=[26577.97433115] | 27458=expected
    728/1934 - predicted=[26744.26975157] | 24456=expected
    729/1934 - predicted=[24274.07365322] | 29405=expected
    730/1934 - predicted=[28346.43340415] | 23152=expected
    731/1934 - predicted=[23201.18965832] | 14359=expected
    732/1934 - predicted=[15966.13628682] | 8123=expected
    733/1934 - predicted=[10833.33133993] | 13395=expected
    734/1934 - predicted=[15172.10495532] | 24707=expected
    735/1934 - predicted=[24480.02911151] | 28149=expected
    736/1934 - predicted=[27311.90693244] | 26558=expected
    737/1934 - predicted=[26002.99350863] | 25029=expected
    738/1934 - predicted=[24745.08184103] | 25802=expected
    739/1934 - predicted=[25381.07777581] | 26842=expected
    740/1934 - predicted=[26236.76720129] | 26868=expected
    741/1934 - predicted=[26258.2208377] | 28755=expected
    742/1934 - predicted=[27810.83837892] | 27397=expected
    743/1934 - predicted=[26693.61702761] | 25185=expected
    744/1934 - predicted=[24873.75070074] | 28555=expected
    745/1934 - predicted=[27646.44543714] | 20584=expected
    746/1934 - predicted=[21088.56949575] | 12909=expected
    747/1934 - predicted=[14774.00519136] | 8053=expected
    748/1934 - predicted=[10777.12490056] | 5623=expected
    749/1934 - predicted=[8775.38746587] | 13095=expected
    750/1934 - predicted=[14925.27913859] | 23991=expected
    751/1934 - predicted=[23890.625206] | 27528=expected
    752/1934 - predicted=[26800.52487498] | 27003=expected
    753/1934 - predicted=[26368.67221638] | 25009=expected
    754/1934 - predicted=[24728.25120402] | 24988=expected
    755/1934 - predicted=[24710.99918012] | 26189=expected
    756/1934 - predicted=[25699.08855228] | 25550=expected
    757/1934 - predicted=[25173.42504398] | 28083=expected
    758/1934 - predicted=[27257.39110878] | 27255=expected
    759/1934 - predicted=[26576.26156515] | 23923=expected
    760/1934 - predicted=[23835.05421422] | 33118=expected
    761/1934 - predicted=[31399.77889531] | 32431=expected
    762/1934 - predicted=[30834.8565286] | 28454=expected
    763/1934 - predicted=[27562.9104187] | 24829=expected
    764/1934 - predicted=[24580.73792144] | 20934=expected
    765/1934 - predicted=[21376.50861615] | 15350=expected
    766/1934 - predicted=[16782.59234081] | 10226=expected
    767/1934 - predicted=[12566.0714715] | 9282=expected
    768/1934 - predicted=[11788.31286788] | 15101=expected
    769/1934 - predicted=[16576.61664161] | 21821=expected
    770/1934 - predicted=[22105.45544779] | 24821=expected
    771/1934 - predicted=[24573.47682065] | 27683=expected
    772/1934 - predicted=[26928.03123554] | 29421=expected
    773/1934 - predicted=[28358.01359992] | 30902=expected
    774/1934 - predicted=[29576.6857574] | 29981=expected
    775/1934 - predicted=[28819.09878981] | 31158=expected
    776/1934 - predicted=[29787.71705138] | 27468=expected
    777/1934 - predicted=[26751.78951833] | 30259=expected
    778/1934 - predicted=[29048.2085505] | 33975=expected
    779/1934 - predicted=[32106.13398576] | 36218=expected
    780/1934 - predicted=[33952.60764838] | 31711=expected
    781/1934 - predicted=[30243.86223584] | 29962=expected
    782/1934 - predicted=[28804.86556666] | 32746=expected
    783/1934 - predicted=[31096.00671506] | 33512=expected
    784/1934 - predicted=[31726.77226493] | 29208=expected
    785/1934 - predicted=[28185.04747375] | 31616=expected
    786/1934 - predicted=[30166.76791653] | 27378=expected
    787/1934 - predicted=[26679.44151048] | 22568=expected
    788/1934 - predicted=[22721.67408872] | 14739=expected
    789/1934 - predicted=[16279.76248393] | 7388=expected
    790/1934 - predicted=[10229.27382403] | 10901=expected
    791/1934 - predicted=[13120.196596] | 16245=expected
    792/1934 - predicted=[17518.09381735] | 22701=expected
    793/1934 - predicted=[22830.42727078] | 28446=expected
    794/1934 - predicted=[27557.42897653] | 32801=expected
    795/1934 - predicted=[31141.16633085] | 33251=expected
    796/1934 - predicted=[31511.86972353] | 31542=expected
    797/1934 - predicted=[30105.73152425] | 29374=expected
    798/1934 - predicted=[28321.82165367] | 25020=expected
    799/1934 - predicted=[24739.12741157] | 25397=expected
    800/1934 - predicted=[25049.3631333] | 25644=expected
    801/1934 - predicted=[25252.63578927] | 22549=expected
    802/1934 - predicted=[22705.99647721] | 20716=expected
    803/1934 - predicted=[21197.73233057] | 19643=expected
    804/1934 - predicted=[20314.77071928] | 14151=expected
    805/1934 - predicted=[15795.38238928] | 10916=expected
    806/1934 - predicted=[13132.44926223] | 6934=expected
    807/1934 - predicted=[9853.49470941] | 14114=expected
    808/1934 - predicted=[15763.65846564] | 24523=expected
    809/1934 - predicted=[24329.43127028] | 27240=expected
    810/1934 - predicted=[26565.08942344] | 24707=expected
    811/1934 - predicted=[24480.89882795] | 22641=expected
    812/1934 - predicted=[22780.96749503] | 21435=expected
    813/1934 - predicted=[21788.63167155] | 22098=expected
    814/1934 - predicted=[22334.13376213] | 22865=expected
    815/1934 - predicted=[22965.21739586] | 25564=expected
    816/1934 - predicted=[25185.99400844] | 25923=expected
    817/1934 - predicted=[25481.42356359] | 24698=expected
    818/1934 - predicted=[24473.50326011] | 29781=expected
    819/1934 - predicted=[28655.9619538] | 31610=expected
    820/1934 - predicted=[30161.22899138] | 29077=expected
    821/1934 - predicted=[28076.99075522] | 27293=expected
    822/1934 - predicted=[26609.10282458] | 24997=expected
    823/1934 - predicted=[24719.91936935] | 15384=expected
    824/1934 - predicted=[16810.2884268] | 9565=expected
    825/1934 - predicted=[12021.11176388] | 12194=expected
    826/1934 - predicted=[14184.31485211] | 22803=expected
    827/1934 - predicted=[22914.21542986] | 26691=expected
    828/1934 - predicted=[26113.0311962] | 25204=expected
    829/1934 - predicted=[24889.65464983] | 23170=expected
    830/1934 - predicted=[23216.23248166] | 22500=expected
    831/1934 - predicted=[22664.99681799] | 23255=expected
    832/1934 - predicted=[23286.14714587] | 23626=expected
    833/1934 - predicted=[23591.37859667] | 26134=expected
    834/1934 - predicted=[25654.79841982] | 26266=expected
    835/1934 - predicted=[25763.44712885] | 22899=expected
    836/1934 - predicted=[22993.34215174] | 25990=expected
    837/1934 - predicted=[25536.37097056] | 28889=expected
    838/1934 - predicted=[27921.54996048] | 29131=expected
    839/1934 - predicted=[28120.78874326] | 28933=expected
    840/1934 - predicted=[27958.00557716] | 28226=expected
    841/1934 - predicted=[27376.41307172] | 25647=expected
    842/1934 - predicted=[25254.57908413] | 21025=expected
    843/1934 - predicted=[21451.93512595] | 15804=expected
    844/1934 - predicted=[17156.28909692] | 11350=expected
    845/1934 - predicted=[13490.89209671] | 8502=expected
    846/1934 - predicted=[11146.06377342] | 12989=expected
    847/1934 - predicted=[14838.58420534] | 23504=expected
    848/1934 - predicted=[23490.76360475] | 28037=expected
    849/1934 - predicted=[27220.19346444] | 25798=expected
    850/1934 - predicted=[25378.15109554] | 23646=expected
    851/1934 - predicted=[23607.6937245] | 23388=expected
    852/1934 - predicted=[23395.43692595] | 24271=expected
    853/1934 - predicted=[24121.89211184] | 24015=expected
    854/1934 - predicted=[23911.29001616] | 26616=expected
    855/1934 - predicted=[26051.18327683] | 26501=expected
    856/1934 - predicted=[25956.62494324] | 23596=expected
    857/1934 - predicted=[23566.67503336] | 28843=expected
    858/1934 - predicted=[27883.42864257] | 31960=expected
    859/1934 - predicted=[30448.15928238] | 31866=expected
    860/1934 - predicted=[30371.09688618] | 29737=expected
    861/1934 - predicted=[28619.5241039] | 20077=expected
    862/1934 - predicted=[20672.11737428] | 13137=expected
    863/1934 - predicted=[14962.34830324] | 12970=expected
    864/1934 - predicted=[14824.49489546] | 23877=expected
    865/1934 - predicted=[23797.88021664] | 27695=expected
    866/1934 - predicted=[26938.59328606] | 25703=expected
    867/1934 - predicted=[25300.01178976] | 24517=expected
    868/1934 - predicted=[24324.44294876] | 24277=expected
    869/1934 - predicted=[24127.03606818] | 25284=expected
    870/1934 - predicted=[24955.40481851] | 25890=expected
    871/1934 - predicted=[25453.93169404] | 27373=expected
    872/1934 - predicted=[26673.90810287] | 26593=expected
    873/1934 - predicted=[26032.33461549] | 23971=expected
    874/1934 - predicted=[23875.50622268] | 27946=expected
    875/1934 - predicted=[27145.34599745] | 26880=expected
    876/1934 - predicted=[26268.51877654] | 18701=expected
    877/1934 - predicted=[19540.72310404] | 11172=expected
    878/1934 - predicted=[13346.90431193] | 5254=expected
    879/1934 - predicted=[8475.9025586] | 12782=expected
    880/1934 - predicted=[14670.54136376] | 22931=expected
    881/1934 - predicted=[23019.48404278] | 27104=expected
    882/1934 - predicted=[26451.84661081] | 24762=expected
    883/1934 - predicted=[24525.55241831] | 24706=expected
    884/1934 - predicted=[24479.51216478] | 24322=expected
    885/1934 - predicted=[24163.68756777] | 25398=expected
    886/1934 - predicted=[25048.72389723] | 25058=expected
    887/1934 - predicted=[24769.09946448] | 28185=expected
    888/1934 - predicted=[27341.15348049] | 27021=expected
    889/1934 - predicted=[26383.80458465] | 24596=expected
    890/1934 - predicted=[24389.24522914] | 34000=expected
    891/1934 - predicted=[32124.29282905] | 34303=expected
    892/1934 - predicted=[32374.03156376] | 33215=expected
    893/1934 - predicted=[31479.37888888] | 29032=expected
    894/1934 - predicted=[28038.52923782] | 23377=expected
    895/1934 - predicted=[23387.17823325] | 18124=expected
    896/1934 - predicted=[19066.59334076] | 13059=expected
    897/1934 - predicted=[14900.0891485] | 8203=expected
    898/1934 - predicted=[10904.14874373] | 6278=expected
    899/1934 - predicted=[9318.61542108] | 10868=expected
    900/1934 - predicted=[13095.2251802] | 15549=expected
    901/1934 - predicted=[16946.46679538] | 23069=expected
    902/1934 - predicted=[23132.78770601] | 26970=expected
    903/1934 - predicted=[26341.70933815] | 30023=expected
    904/1934 - predicted=[28853.2539491] | 31736=expected
    905/1934 - predicted=[30262.70773941] | 31829=expected
    906/1934 - predicted=[30339.49302302] | 30293=expected
    907/1934 - predicted=[29076.0177887] | 30763=expected
    908/1934 - predicted=[29462.88668096] | 28240=expected
    909/1934 - predicted=[27387.33800204] | 31889=expected
    910/1934 - predicted=[30389.54711075] | 36446=expected
    911/1934 - predicted=[34139.61774528] | 37017=expected
    912/1934 - predicted=[34610.32993395] | 30906=expected
    913/1934 - predicted=[29581.77689151] | 29611=expected
    914/1934 - predicted=[28516.437752] | 32221=expected
    915/1934 - predicted=[30664.17635368] | 31411=expected
    916/1934 - predicted=[29997.93589125] | 29287=expected
    917/1934 - predicted=[28250.40866887] | 14351=expected
    918/1934 - predicted=[15962.54340888] | 10086=expected
    919/1934 - predicted=[12452.74256494] | 6249=expected
    920/1934 - predicted=[9293.67500462] | 6578=expected
    921/1934 - predicted=[9563.02326663] | 7969=expected
    922/1934 - predicted=[10706.86484343] | 11110=expected
    923/1934 - predicted=[13291.66047458] | 15833=expected
    924/1934 - predicted=[17178.61040949] | 22472=expected
    925/1934 - predicted=[22641.82777761] | 25304=expected
    926/1934 - predicted=[24972.11601586] | 29012=expected
    927/1934 - predicted=[28023.3160899] | 29431=expected
    928/1934 - predicted=[28368.24247856] | 27842=expected
    929/1934 - predicted=[27060.77603099] | 26419=expected
    930/1934 - predicted=[25889.8956442] | 23576=expected
    931/1934 - predicted=[23550.55009236] | 24355=expected
    932/1934 - predicted=[24191.55203655] | 26206=expected
    933/1934 - predicted=[25714.66761569] | 25159=expected
    934/1934 - predicted=[24853.17873733] | 22387=expected
    935/1934 - predicted=[22572.27082202] | 21014=expected
    936/1934 - predicted=[21442.48501775] | 17493=expected
    937/1934 - predicted=[18545.12640445] | 12377=expected
    938/1934 - predicted=[14334.71615258] | 8918=expected
    939/1934 - predicted=[11486.86644059] | 5530=expected
    940/1934 - predicted=[8696.14071387] | 13655=expected
    941/1934 - predicted=[15384.95015927] | 23121=expected
    942/1934 - predicted=[23175.29209935] | 25227=expected
    943/1934 - predicted=[24908.28472569] | 23885=expected
    944/1934 - predicted=[23803.99787788] | 22168=expected
    945/1934 - predicted=[22391.11625678] | 22083=expected
    946/1934 - predicted=[22321.15199931] | 22865=expected
    947/1934 - predicted=[22964.62631475] | 23860=expected
    948/1934 - predicted=[23783.38425892] | 26950=expected
    949/1934 - predicted=[26326.09890813] | 26088=expected
    950/1934 - predicted=[25616.82284992] | 24584=expected
    951/1934 - predicted=[24379.24448175] | 28881=expected
    952/1934 - predicted=[27915.20649162] | 32558=expected
    953/1934 - predicted=[30941.36265256] | 30778=expected
    954/1934 - predicted=[29476.683828] | 29148=expected
    955/1934 - predicted=[28135.41727019] | 29376=expected
    956/1934 - predicted=[28323.18539757] | 26459=expected
    957/1934 - predicted=[25922.75342831] | 16333=expected
    958/1934 - predicted=[17590.31037689] | 9083=expected
    959/1934 - predicted=[11623.18126994] | 12929=expected
    960/1934 - predicted=[14788.33065486] | 22794=expected
    961/1934 - predicted=[22906.42511335] | 25291=expected
    962/1934 - predicted=[24960.96376993] | 24108=expected
    963/1934 - predicted=[23987.61043659] | 23660=expected
    964/1934 - predicted=[23619.00432432] | 24893=expected
    965/1934 - predicted=[24633.52558528] | 25875=expected
    966/1934 - predicted=[25441.54646595] | 26091=expected
    967/1934 - predicted=[25619.31550028] | 28417=expected
    968/1934 - predicted=[27533.26051206] | 30090=expected
    969/1934 - predicted=[28910.03164487] | 26764=expected
    970/1934 - predicted=[26173.30572119] | 30605=expected
    971/1934 - predicted=[29333.94579901] | 32666=expected
    972/1934 - predicted=[31030.23403121] | 33532=expected
    973/1934 - predicted=[31743.30528514] | 33193=expected
    974/1934 - predicted=[31464.69757976] | 30009=expected
    975/1934 - predicted=[28844.51267122] | 18963=expected
    976/1934 - predicted=[19755.21323033] | 10469=expected
    977/1934 - predicted=[12765.41081664] | 13558=expected
    978/1934 - predicted=[15307.21363871] | 24966=expected
    979/1934 - predicted=[24694.01596056] | 28745=expected
    980/1934 - predicted=[27803.15421054] | 25890=expected
    981/1934 - predicted=[25454.30004624] | 24068=expected
    982/1934 - predicted=[23955.34300228] | 24252=expected
    983/1934 - predicted=[24106.73158517] | 25207=expected
    984/1934 - predicted=[24892.43635727] | 25741=expected
    985/1934 - predicted=[25331.79681737] | 27904=expected
    986/1934 - predicted=[27111.40405608] | 27381=expected
    987/1934 - predicted=[26681.19018091] | 23314=expected
    988/1934 - predicted=[23335.22595742] | 28227=expected
    989/1934 - predicted=[27377.17750859] | 22582=expected
    990/1934 - predicted=[22733.10209783] | 13063=expected
    991/1934 - predicted=[14901.93621723] | 7337=expected
    992/1934 - predicted=[10189.30293829] | 13509=expected
    993/1934 - predicted=[15268.11224907] | 24577=expected
    994/1934 - predicted=[24373.68769144] | 28006=expected
    995/1934 - predicted=[27194.39374631] | 25634=expected
    996/1934 - predicted=[25243.24088294] | 24155=expected
    997/1934 - predicted=[24026.66671413] | 24791=expected
    998/1934 - predicted=[24549.84100937] | 25665=expected
    999/1934 - predicted=[25268.80391218] | 26000=expected
    1000/1934 - predicted=[25544.40838961] | 28272=expected
    1001/1934 - predicted=[27413.41524359] | 28022=expected
    1002/1934 - predicted=[27207.85668229] | 24637=expected
    1003/1934 - predicted=[24423.39722854] | 28629=expected
    1004/1934 - predicted=[27707.21195028] | 19907=expected
    1005/1934 - predicted=[20532.84088022] | 11618=expected
    1006/1934 - predicted=[13714.27125287] | 5397=expected
    1007/1934 - predicted=[8594.32412073] | 12880=expected
    1008/1934 - predicted=[14751.61324037] | 22460=expected
    1009/1934 - predicted=[22632.16017931] | 26497=expected
    1010/1934 - predicted=[25952.54017646] | 25917=expected
    1011/1934 - predicted=[25475.54142265] | 25856=expected
    1012/1934 - predicted=[25425.4088844] | 26948=expected
    1013/1934 - predicted=[26323.62271475] | 28357=expected
    1014/1934 - predicted=[27482.62126541] | 28356=expected
    1015/1934 - predicted=[27481.90166304] | 29739=expected
    1016/1934 - predicted=[28619.60657553] | 26900=expected
    1017/1934 - predicted=[26284.49230542] | 34672=expected
    1018/1934 - predicted=[32677.57021289] | 34629=expected
    1019/1934 - predicted=[32642.70901654] | 34761=expected
    1020/1934 - predicted=[32751.83196826] | 32334=expected
    1021/1934 - predicted=[30755.44847412] | 27440=expected
    1022/1934 - predicted=[26729.56186169] | 22047=expected
    1023/1934 - predicted=[22293.54213995] | 17218=expected
    1024/1934 - predicted=[18321.39852547] | 12307=expected
    1025/1934 - predicted=[14281.16764333] | 7696=expected
    1026/1934 - predicted=[10486.34470536] | 9873=expected
    1027/1934 - predicted=[12276.96695072] | 15330=expected
    1028/1934 - predicted=[16766.83017333] | 21492=expected
    1029/1934 - predicted=[21836.06867197] | 25388=expected
    1030/1934 - predicted=[25040.90964873] | 25963=expected
    1031/1934 - predicted=[25513.93953647] | 27863=expected
    1032/1934 - predicted=[27076.95933847] | 26869=expected
    1033/1934 - predicted=[26259.34541901] | 26080=expected
    1034/1934 - predicted=[25610.35453561] | 26123=expected
    1035/1934 - predicted=[25645.77151363] | 23605=expected
    1036/1934 - predicted=[23574.47558197] | 28797=expected
    1037/1934 - predicted=[27845.44075435] | 32879=expected
    1038/1934 - predicted=[31203.75053655] | 34810=expected
    1039/1934 - predicted=[32792.95824289] | 29112=expected
    1040/1934 - predicted=[28105.10199825] | 29458=expected
    1041/1934 - predicted=[28389.88117702] | 33261=expected
    1042/1934 - predicted=[31518.8812331] | 33258=expected
    1043/1934 - predicted=[31516.79776791] | 29622=expected
    1044/1934 - predicted=[28525.4157742] | 25124=expected
    1045/1934 - predicted=[24825.0360993] | 20954=expected
    1046/1934 - predicted=[21394.62690117] | 14892=expected
    1047/1934 - predicted=[16407.53539218] | 9527=expected
    1048/1934 - predicted=[11992.66126605] | 7049=expected
    1049/1934 - predicted=[9952.09639559] | 12192=expected
    1050/1934 - predicted=[14184.32868344] | 18285=expected
    1051/1934 - predicted=[19197.7747934] | 24374=expected
    1052/1934 - predicted=[24207.25657686] | 26717=expected
    1053/1934 - predicted=[26134.84496964] | 29243=expected
    1054/1934 - predicted=[28213.10314603] | 28826=expected
    1055/1934 - predicted=[27870.14707194] | 28960=expected
    1056/1934 - predicted=[27980.51525643] | 28836=expected
    1057/1934 - predicted=[27878.61371692] | 27538=expected
    1058/1934 - predicted=[26810.7835055] | 27752=expected
    1059/1934 - predicted=[26986.93030364] | 28036=expected
    1060/1934 - predicted=[27220.67868593] | 23888=expected
    1061/1934 - predicted=[23808.02149495] | 21162=expected
    1062/1934 - predicted=[21565.30783462] | 19754=expected
    1063/1934 - predicted=[20406.87241177] | 16980=expected
    1064/1934 - predicted=[18124.47874612] | 12747=expected
    1065/1934 - predicted=[14641.20615191] | 7451=expected
    1066/1934 - predicted=[10281.85080484] | 5382=expected
    1067/1934 - predicted=[8577.05841159] | 13497=expected
    1068/1934 - predicted=[15256.71486622] | 24253=expected
    1069/1934 - predicted=[24107.36158063] | 26611=expected
    1070/1934 - predicted=[26047.43894424] | 24915=expected
    1071/1934 - predicted=[24652.08098194] | 23439=expected
    1072/1934 - predicted=[23437.72032835] | 22095=expected
    1073/1934 - predicted=[22331.94444981] | 23180=expected
    1074/1934 - predicted=[23224.60889232] | 23498=expected
    1075/1934 - predicted=[23486.23914782] | 25607=expected
    1076/1934 - predicted=[25221.4168072] | 26427=expected
    1077/1934 - predicted=[25896.11273248] | 24763=expected
    1078/1934 - predicted=[24527.09143114] | 29714=expected
    1079/1934 - predicted=[28600.59336274] | 29855=expected
    1080/1934 - predicted=[28716.76591524] | 27640=expected
    1081/1934 - predicted=[26894.38657984] | 27958=expected
    1082/1934 - predicted=[27156.11519805] | 26840=expected
    1083/1934 - predicted=[26236.32475105] | 16400=expected
    1084/1934 - predicted=[17647.06551419] | 9789=expected
    1085/1934 - predicted=[12206.92855457] | 12853=expected
    1086/1934 - predicted=[14727.89901089] | 23975=expected
    1087/1934 - predicted=[23878.63569996] | 27136=expected
    1088/1934 - predicted=[26479.02795363] | 25028=expected
    1089/1934 - predicted=[24744.93329886] | 23810=expected
    1090/1934 - predicted=[23742.98268472] | 23443=expected
    1091/1934 - predicted=[23441.08079568] | 23900=expected
    1092/1934 - predicted=[23817.02564536] | 24330=expected
    1093/1934 - predicted=[24170.76623273] | 27518=expected
    1094/1934 - predicted=[26793.36062246] | 26770=expected
    1095/1934 - predicted=[26178.0866001] | 23525=expected
    1096/1934 - predicted=[23508.66576798] | 29319=expected
    1097/1934 - predicted=[28274.97773714] | 32606=expected
    1098/1934 - predicted=[30979.37437608] | 32694=expected
    1099/1934 - predicted=[31052.10772593] | 30486=expected
    1100/1934 - predicted=[29235.70034789] | 21416=expected
    1101/1934 - predicted=[21774.25908578] | 11787=expected
    1102/1934 - predicted=[13853.0631377] | 13459=expected
    1103/1934 - predicted=[15228.26783812] | 24350=expected
    1104/1934 - predicted=[24187.33977177] | 28397=expected
    1105/1934 - predicted=[27516.07393665] | 26385=expected
    1106/1934 - predicted=[25861.22516587] | 24212=expected
    1107/1934 - predicted=[24073.95640864] | 24549=expected
    1108/1934 - predicted=[24351.15099225] | 25525=expected
    1109/1934 - predicted=[25153.93137287] | 25686=expected
    1110/1934 - predicted=[25286.38830038] | 26924=expected
    1111/1934 - predicted=[26304.69928444] | 27394=expected
    1112/1934 - predicted=[26691.35129361] | 23837=expected
    1113/1934 - predicted=[23765.71984902] | 28695=expected
    1114/1934 - predicted=[27761.43505422] | 24123=expected
    1115/1934 - predicted=[24001.02111976] | 13419=expected
    1116/1934 - predicted=[15197.36948083] | 7389=expected
    1117/1934 - predicted=[10236.00173718] | 15294=expected
    1118/1934 - predicted=[16739.13892628] | 25753=expected
    1119/1934 - predicted=[25340.88954604] | 28722=expected
    1120/1934 - predicted=[27782.55899584] | 26521=expected
    1121/1934 - predicted=[25972.5767625] | 24831=expected
    1122/1934 - predicted=[24582.82893366] | 25227=expected
    1123/1934 - predicted=[24908.5037999] | 25743=expected
    1124/1934 - predicted=[25332.87046108] | 25869=expected
    1125/1934 - predicted=[25436.52571538] | 26439=expected
    1126/1934 - predicted=[25905.31742704] | 22940=expected
    1127/1934 - predicted=[23027.92079746] | 28640=expected
    1128/1934 - predicted=[27715.28736077] | 20452=expected
    1129/1934 - predicted=[20982.1531291] | 12005=expected
    1130/1934 - predicted=[14035.77648896] | 5656=expected
    1131/1934 - predicted=[8812.25047555] | 13465=expected
    1132/1934 - predicted=[15235.76557364] | 24393=expected
    1133/1934 - predicted=[24222.12056044] | 27749=expected
    1134/1934 - predicted=[26981.52992782] | 25889=expected
    1135/1934 - predicted=[25452.23553273] | 24095=expected
    1136/1934 - predicted=[23977.20822927] | 24777=expected
    1137/1934 - predicted=[24537.96931583] | 25712=expected
    1138/1934 - predicted=[25306.76566168] | 26129=expected
    1139/1934 - predicted=[25649.67036805] | 29304=expected
    1140/1934 - predicted=[28260.33859264] | 28418=expected
    1141/1934 - predicted=[27531.93427031] | 24499=expected
    1142/1934 - predicted=[24309.64452965] | 29153=expected
    1143/1934 - predicted=[28136.28479988] | 33045=expected
    1144/1934 - predicted=[31336.83148365] | 33455=expected
    1145/1934 - predicted=[31674.38166682] | 28187=expected
    1146/1934 - predicted=[27342.48186793] | 24286=expected
    1147/1934 - predicted=[24134.97629872] | 19021=expected
    1148/1934 - predicted=[19806.0286131] | 13912=expected
    1149/1934 - predicted=[15604.92945758] | 8783=expected
    1150/1934 - predicted=[11386.13621073] | 7510=expected
    1151/1934 - predicted=[10337.81671398] | 10325=expected
    1152/1934 - predicted=[12652.69146626] | 15873=expected
    1153/1934 - predicted=[17215.7368191] | 22739=expected
    1154/1934 - predicted=[22861.99934909] | 26860=expected
    1155/1934 - predicted=[26250.68752526] | 28476=expected
    1156/1934 - predicted=[27579.62680313] | 31342=expected
    1157/1934 - predicted=[29936.65224305] | 34456=expected
    1158/1934 - predicted=[32498.07425752] | 34199=expected
    1159/1934 - predicted=[32287.16108557] | 30412=expected
    1160/1934 - predicted=[29172.64829258] | 26463=expected
    1161/1934 - predicted=[25925.0747374] | 28557=expected
    1162/1934 - predicted=[27647.19406014] | 33780=expected
    1163/1934 - predicted=[31942.95670619] | 32238=expected
    1164/1934 - predicted=[30674.98517726] | 26764=expected
    1165/1934 - predicted=[26173.04240778] | 25615=expected
    1166/1934 - predicted=[25228.1826291] | 29814=expected
    1167/1934 - predicted=[28681.42091267] | 31102=expected
    1168/1934 - predicted=[29740.90565669] | 27872=expected
    1169/1934 - predicted=[27084.57006341] | 25273=expected
    1170/1934 - predicted=[24947.24407911] | 21630=expected
    1171/1934 - predicted=[21951.38914272] | 15852=expected
    1172/1934 - predicted=[17199.63570972] | 9891=expected
    1173/1934 - predicted=[12296.28314147] | 6827=expected
    1174/1934 - predicted=[9774.36394018] | 11251=expected
    1175/1934 - predicted=[13413.53541106] | 17499=expected
    1176/1934 - predicted=[18552.90300586] | 23441=expected
    1177/1934 - predicted=[23439.84289848] | 26565=expected
    1178/1934 - predicted=[26009.06592743] | 29612=expected
    1179/1934 - predicted=[28515.10616566] | 29501=expected
    1180/1934 - predicted=[28423.9580793] | 29342=expected
    1181/1934 - predicted=[28293.32402574] | 29807=expected
    1182/1934 - predicted=[28675.9278049] | 27202=expected
    1183/1934 - predicted=[26533.46598434] | 27718=expected
    1184/1934 - predicted=[26957.93053987] | 28024=expected
    1185/1934 - predicted=[27209.69167137] | 23965=expected
    1186/1934 - predicted=[23871.38992803] | 21663=expected
    1187/1934 - predicted=[21978.14918491] | 21618=expected
    1188/1934 - predicted=[21941.11210895] | 17338=expected
    1189/1934 - predicted=[18420.98409394] | 12775=expected
    1190/1934 - predicted=[14667.55078218] | 7546=expected
    1191/1934 - predicted=[10364.87677456] | 12655=expected
    1192/1934 - predicted=[14567.867555] | 22574=expected
    1193/1934 - predicted=[22726.70442423] | 26256=expected
    1194/1934 - predicted=[25754.87280006] | 24218=expected
    1195/1934 - predicted=[24078.80254067] | 22229=expected
    1196/1934 - predicted=[22443.02028211] | 22612=expected
    1197/1934 - predicted=[22757.98985889] | 23538=expected
    1198/1934 - predicted=[23519.53760973] | 23920=expected
    1199/1934 - predicted=[23833.70257736] | 25691=expected
    1200/1934 - predicted=[25290.21501565] | 26704=expected
    1201/1934 - predicted=[26123.37359594] | 24543=expected
    1202/1934 - predicted=[24346.15550122] | 28746=expected
    1203/1934 - predicted=[27802.82338229] | 32271=expected
    1204/1934 - predicted=[30702.23708003] | 30213=expected
    1205/1934 - predicted=[29009.70880061] | 27951=expected
    1206/1934 - predicted=[27149.38042901] | 27904=expected
    1207/1934 - predicted=[27110.81342115] | 25182=expected
    1208/1934 - predicted=[24872.16155473] | 16775=expected
    1209/1934 - predicted=[17958.12231641] | 9846=expected
    1210/1934 - predicted=[12258.50011301] | 13213=expected
    1211/1934 - predicted=[15027.80788578] | 22920=expected
    1212/1934 - predicted=[23011.4369643] | 26562=expected
    1213/1934 - predicted=[26006.44933741] | 24902=expected
    1214/1934 - predicted=[24641.37814372] | 24318=expected
    1215/1934 - predicted=[24161.14617388] | 23601=expected
    1216/1934 - predicted=[23571.53399126] | 25271=expected
    1217/1934 - predicted=[24944.86076918] | 25262=expected
    1218/1934 - predicted=[24937.48836702] | 27597=expected
    1219/1934 - predicted=[26857.73198182] | 27115=expected
    1220/1934 - predicted=[26461.42103575] | 22918=expected
    1221/1934 - predicted=[23010.04407392] | 26757=expected
    1222/1934 - predicted=[26166.99441278] | 30543=expected
    1223/1934 - predicted=[29280.5580437] | 30039=expected
    1224/1934 - predicted=[28866.24377818] | 28067=expected
    1225/1934 - predicted=[27244.60146833] | 28878=expected
    1226/1934 - predicted=[27911.65835961] | 25681=expected
    1227/1934 - predicted=[25282.58520939] | 19855=expected
    1228/1934 - predicted=[20491.6542419] | 13197=expected
    1229/1934 - predicted=[15016.11979326] | 7660=expected
    1230/1934 - predicted=[10460.84611081] | 12900=expected
    1231/1934 - predicted=[14770.9594104] | 21169=expected
    1232/1934 - predicted=[21571.6318987] | 26443=expected
    1233/1934 - predicted=[25908.51626012] | 24321=expected
    1234/1934 - predicted=[24163.60443297] | 22868=expected
    1235/1934 - predicted=[22968.80577753] | 25248=expected
    1236/1934 - predicted=[24925.88246135] | 26879=expected
    1237/1934 - predicted=[26267.10143785] | 26738=expected
    1238/1934 - predicted=[26151.21467035] | 27454=expected
    1239/1934 - predicted=[26740.06166129] | 27356=expected
    1240/1934 - predicted=[26659.54542263] | 24638=expected
    1241/1934 - predicted=[24424.52336493] | 27376=expected
    1242/1934 - predicted=[26676.04298286] | 30271=expected
    1243/1934 - predicted=[29056.83517124] | 28031=expected
    1244/1934 - predicted=[27214.86184167] | 24748=expected
    1245/1934 - predicted=[24515.21812398] | 24634=expected
    1246/1934 - predicted=[24421.49420683] | 23990=expected
    1247/1934 - predicted=[23891.94423348] | 19597=expected
    1248/1934 - predicted=[20279.56636186] | 15157=expected
    1249/1934 - predicted=[16628.24945531] | 11374=expected
    1250/1934 - predicted=[13516.52179288] | 8556=expected
    1251/1934 - predicted=[11197.59896047] | 6303=expected
    1252/1934 - predicted=[9342.6188872] | 8028=expected
    1253/1934 - predicted=[10760.83203464] | 9674=expected
    1254/1934 - predicted=[12114.30344069] | 10615=expected
    1255/1934 - predicted=[12887.82715753] | 13741=expected
    1256/1934 - predicted=[15459.42547692] | 16317=expected
    1257/1934 - predicted=[17578.49849876] | 17272=expected
    1258/1934 - predicted=[18363.99091697] | 17679=expected
    1259/1934 - predicted=[18698.68198354] | 18946=expected
    1260/1934 - predicted=[19740.89379604] | 19593=expected
    1261/1934 - predicted=[20273.07423773] | 18127=expected
    1262/1934 - predicted=[19066.96614948] | 17773=expected
    1263/1934 - predicted=[18775.61589071] | 16703=expected
    1264/1934 - predicted=[17895.17727235] | 18416=expected
    1265/1934 - predicted=[19304.35116783] | 19033=expected
    1266/1934 - predicted=[19811.85955444] | 19667=expected
    1267/1934 - predicted=[20333.36993824] | 16615=expected
    1268/1934 - predicted=[17822.37709093] | 12646=expected
    1269/1934 - predicted=[14556.46907935] | 9677=expected
    1270/1934 - predicted=[12112.58329379] | 12993=expected
    1271/1934 - predicted=[14841.02232674] | 16652=expected
    1272/1934 - predicted=[17851.6745714] | 18892=expected
    1273/1934 - predicted=[19694.63597756] | 20166=expected
    1274/1934 - predicted=[20742.78110082] | 22418=expected
    1275/1934 - predicted=[22595.60134317] | 23189=expected
    1276/1934 - predicted=[23229.9306376] | 24579=expected
    1277/1934 - predicted=[24373.55403082] | 24789=expected
    1278/1934 - predicted=[24546.35056701] | 25696=expected
    1279/1934 - predicted=[25292.61215525] | 25210=expected
    1280/1934 - predicted=[24892.78513508] | 24321=expected
    1281/1934 - predicted=[24161.3804693] | 20244=expected
    1282/1934 - predicted=[20807.0403528] | 21623=expected
    1283/1934 - predicted=[21941.57145025] | 22839=expected
    1284/1934 - predicted=[22942.00584175] | 18444=expected
    1285/1934 - predicted=[19326.02172348] | 14921=expected
    1286/1934 - predicted=[16427.15416457] | 11915=expected
    1287/1934 - predicted=[13953.1569464] | 9620=expected
    1288/1934 - predicted=[12063.63437072] | 9088=expected
    1289/1934 - predicted=[11624.83791287] | 14542=expected
    1290/1934 - predicted=[16113.54638226] | 18529=expected
    1291/1934 - predicted=[19394.46251785] | 21548=expected
    1292/1934 - predicted=[21878.6604856] | 24698=expected
    1293/1934 - predicted=[24470.61543195] | 26299=expected
    1294/1934 - predicted=[25788.02097901] | 25863=expected
    1295/1934 - predicted=[25429.30104127] | 26964=expected
    1296/1934 - predicted=[26335.31191345] | 25767=expected
    1297/1934 - predicted=[25350.39973639] | 27146=expected
    1298/1934 - predicted=[26485.17037836] | 27912=expected
    1299/1934 - predicted=[27115.56701338] | 29559=expected
    1300/1934 - predicted=[28470.98685346] | 24764=expected
    1301/1934 - predicted=[24525.31607624] | 23838=expected
    1302/1934 - predicted=[23763.37575918] | 26410=expected
    1303/1934 - predicted=[25879.7528666] | 23539=expected
    1304/1934 - predicted=[23517.39237236] | 19556=expected
    1305/1934 - predicted=[20240.0233156] | 16236=expected
    1306/1934 - predicted=[17507.98473448] | 14005=expected
    1307/1934 - predicted=[15671.7520175] | 10411=expected
    1308/1934 - predicted=[12713.23233741] | 7385=expected
    1309/1934 - predicted=[10221.21635458] | 6446=expected
    1310/1934 - predicted=[9446.71405745] | 9537=expected
    1311/1934 - predicted=[11990.83555997] | 14733=expected
    1312/1934 - predicted=[16268.13887997] | 19817=expected
    1313/1934 - predicted=[20452.75460626] | 21811=expected
    1314/1934 - predicted=[22093.86902853] | 24775=expected
    1315/1934 - predicted=[24533.32862076] | 26588=expected
    1316/1934 - predicted=[26025.52127756] | 26644=expected
    1317/1934 - predicted=[26071.66612142] | 25656=expected
    1318/1934 - predicted=[25258.54444645] | 25086=expected
    1319/1934 - predicted=[24789.44377585] | 25571=expected
    1320/1934 - predicted=[25188.64572974] | 25456=expected
    1321/1934 - predicted=[25094.02863228] | 23166=expected
    1322/1934 - predicted=[23209.29556446] | 20530=expected
    1323/1934 - predicted=[21039.76778142] | 18335=expected
    1324/1934 - predicted=[19233.10663269] | 14980=expected
    1325/1934 - predicted=[16471.45792123] | 11561=expected
    1326/1934 - predicted=[13656.55862606] | 7316=expected
    1327/1934 - predicted=[10160.51354267] | 12412=expected
    1328/1934 - predicted=[14356.05243647] | 22305=expected
    1329/1934 - predicted=[22499.82605135] | 24873=expected
    1330/1934 - predicted=[24613.44161311] | 23016=expected
    1331/1934 - predicted=[23085.03494859] | 20176=expected
    1332/1934 - predicted=[20747.53206186] | 20460=expected
    1333/1934 - predicted=[20981.23296092] | 20460=expected
    1334/1934 - predicted=[20981.18428962] | 22130=expected
    1335/1934 - predicted=[22355.66590763] | 22047=expected
    1336/1934 - predicted=[22287.33282684] | 24266=expected
    1337/1934 - predicted=[24113.68341294] | 25299=expected
    1338/1934 - predicted=[24963.91691231] | 23150=expected
    1339/1934 - predicted=[23195.19135167] | 26329=expected
    1340/1934 - predicted=[25811.67348267] | 30422=expected
    1341/1934 - predicted=[29180.603151] | 28556=expected
    1342/1934 - predicted=[27644.81962345] | 26107=expected
    1343/1934 - predicted=[25629.17823165] | 25584=expected
    1344/1934 - predicted=[25198.75870638] | 21744=expected
    1345/1934 - predicted=[22038.27719949] | 14867=expected
    1346/1934 - predicted=[16378.03621216] | 9181=expected
    1347/1934 - predicted=[11696.78497477] | 13055=expected
    1348/1934 - predicted=[14885.72237596] | 22810=expected
    1349/1934 - predicted=[22915.1651408] | 27186=expected
    1350/1934 - predicted=[26516.61622558] | 24597=expected
    1351/1934 - predicted=[24385.90586171] | 22171=expected
    1352/1934 - predicted=[22389.34867326] | 22377=expected
    1353/1934 - predicted=[22558.86671662] | 23580=expected
    1354/1934 - predicted=[23548.90656301] | 23155=expected
    1355/1934 - predicted=[23199.13972079] | 25616=expected
    1356/1934 - predicted=[25224.5046248] | 26130=expected
    1357/1934 - predicted=[25647.55949746] | 23357=expected
    1358/1934 - predicted=[23365.45082194] | 27743=expected
    1359/1934 - predicted=[26975.04066377] | 30475=expected
    1360/1934 - predicted=[29223.63190022] | 29384=expected
    1361/1934 - predicted=[28325.84964369] | 30820=expected
    1362/1934 - predicted=[29507.91879119] | 18754=expected
    1363/1934 - predicted=[19577.94158382] | 11180=expected
    1364/1934 - predicted=[13344.47223528] | 12707=expected
    1365/1934 - predicted=[14600.85185226] | 23520=expected
    1366/1934 - predicted=[23499.54061717] | 27518=expected
    1367/1934 - predicted=[26789.28337802] | 24716=expected
    1368/1934 - predicted=[24483.71066343] | 22929=expected
    1369/1934 - predicted=[23013.32483335] | 22666=expected
    1370/1934 - predicted=[22796.91291161] | 23990=expected
    1371/1934 - predicted=[23886.33162509] | 23851=expected
    1372/1934 - predicted=[23771.96665173] | 25791=expected
    1373/1934 - predicted=[25368.26842994] | 25271=expected
    1374/1934 - predicted=[24940.42941228] | 22211=expected
    1375/1934 - predicted=[22422.59844592] | 26517=expected
    1376/1934 - predicted=[25965.64595859] | 30751=expected
    1377/1934 - predicted=[29449.65258755] | 30403=expected
    1378/1934 - predicted=[29163.477326] | 30301=expected
    1379/1934 - predicted=[29079.72421866] | 22579=expected
    1380/1934 - predicted=[22725.75327806] | 13475=expected
    1381/1934 - predicted=[15234.88759382] | 7594=expected
    1382/1934 - predicted=[10394.153597] | 13306=expected
    1383/1934 - predicted=[15095.04500984] | 24794=expected
    1384/1934 - predicted=[24547.60804765] | 29122=expected
    1385/1934 - predicted=[28108.38462607] | 26217=expected
    1386/1934 - predicted=[25718.41485434] | 24319=expected
    1387/1934 - predicted=[24156.95009824] | 24482=expected
    1388/1934 - predicted=[24291.06389667] | 25255=expected
    1389/1934 - predicted=[24927.0320866] | 25539=expected
    1390/1934 - predicted=[25160.70928697] | 27623=expected
    1391/1934 - predicted=[26875.29099889] | 27529=expected
    1392/1934 - predicted=[26798.03247721] | 24002=expected
    1393/1934 - predicted=[23896.35818233] | 28961=expected
    1394/1934 - predicted=[27976.16578296] | 29718=expected
    1395/1934 - predicted=[28599.11805516] | 18872=expected
    1396/1934 - predicted=[19676.38128667] | 11494=expected
    1397/1934 - predicted=[13606.3162356] | 12851=expected
    1398/1934 - predicted=[14722.39775237] | 23437=expected
    1399/1934 - predicted=[23431.31904871] | 28060=expected
    1400/1934 - predicted=[27234.06554064] | 25245=expected
    1401/1934 - predicted=[24918.57171028] | 24747=expected
    1402/1934 - predicted=[24508.96343842] | 24994=expected
    1403/1934 - predicted=[24712.15588993] | 25930=expected
    1404/1934 - predicted=[25482.100434] | 26225=expected
    1405/1934 - predicted=[25724.80028815] | 29591=expected
    1406/1934 - predicted=[28493.6846371] | 28581=expected
    1407/1934 - predicted=[27662.9726441] | 24561=expected
    1408/1934 - predicted=[24356.24926307] | 30185=expected
    1409/1934 - predicted=[28982.39571073] | 33270=expected
    1410/1934 - predicted=[31520.504692] | 30962=expected
    1411/1934 - predicted=[29622.01045884] | 25392=expected
    1412/1934 - predicted=[25040.15425659] | 20051=expected
    1413/1934 - predicted=[20646.95970809] | 13785=expected
    1414/1934 - predicted=[15492.558594] | 8654=expected
    1415/1934 - predicted=[11270.45945436] | 9493=expected
    1416/1934 - predicted=[11959.96015767] | 14867=expected
    1417/1934 - predicted=[16381.42943846] | 21494=expected
    1418/1934 - predicted=[21833.0861526] | 25819=expected
    1419/1934 - predicted=[25390.71095571] | 28402=expected
    1420/1934 - predicted=[27515.50149977] | 30321=expected
    1421/1934 - predicted=[29094.24796466] | 31187=expected
    1422/1934 - predicted=[29806.87628143] | 30089=expected
    1423/1934 - predicted=[28903.76818996] | 30142=expected
    1424/1934 - predicted=[28947.53959746] | 26812=expected
    1425/1934 - predicted=[26208.18604713] | 30695=expected
    1426/1934 - predicted=[29402.61363415] | 35319=expected
    1427/1934 - predicted=[33207.30216832] | 35992=expected
    1428/1934 - predicted=[33761.72489535] | 30206=expected
    1429/1934 - predicted=[29001.09145332] | 29904=expected
    1430/1934 - predicted=[28752.79487587] | 31997=expected
    1431/1934 - predicted=[30475.02420852] | 33455=expected
    1432/1934 - predicted=[31675.02738888] | 32890=expected
    1433/1934 - predicted=[31210.47589944] | 28133=expected
    1434/1934 - predicted=[27296.4956765] | 23105=expected
    1435/1934 - predicted=[23159.87902089] | 16510=expected
    1436/1934 - predicted=[17734.12057262] | 10286=expected
    1437/1934 - predicted=[12612.56986766] | 6883=expected
    1438/1934 - predicted=[9810.75975796] | 11237=expected
    1439/1934 - predicted=[13393.73529072] | 17458=expected
    1440/1934 - predicted=[18512.91216318] | 24111=expected
    1441/1934 - predicted=[23986.75403386] | 27460=expected
    1442/1934 - predicted=[26742.1164418] | 30215=expected
    1443/1934 - predicted=[29008.95172343] | 30772=expected
    1444/1934 - predicted=[29467.44277548] | 31096=expected
    1445/1934 - predicted=[29734.25554892] | 28751=expected
    1446/1934 - predicted=[27804.86445246] | 26566=expected
    1447/1934 - predicted=[26007.13819387] | 26901=expected
    1448/1934 - predicted=[26282.82550328] | 26593=expected
    1449/1934 - predicted=[26029.46510326] | 24214=expected
    1450/1934 - predicted=[24072.11957865] | 21093=expected
    1451/1934 - predicted=[21504.27850861] | 20172=expected
    1452/1934 - predicted=[20746.46566603] | 16483=expected
    1453/1934 - predicted=[17711.09189692] | 11952=expected
    1454/1934 - predicted=[13982.30985142] | 7014=expected
    1455/1934 - predicted=[9917.14656887] | 13027=expected
    1456/1934 - predicted=[14866.0594838] | 22754=expected
    1457/1934 - predicted=[22870.16301697] | 26430=expected
    1458/1934 - predicted=[25894.64795971] | 24612=expected
    1459/1934 - predicted=[24398.89403697] | 21866=expected
    1460/1934 - predicted=[22139.61351892] | 22291=expected
    1461/1934 - predicted=[22489.26389819] | 23453=expected
    1462/1934 - predicted=[23445.29188945] | 24277=expected
    1463/1934 - predicted=[24123.24338295] | 26683=expected
    1464/1934 - predicted=[26102.81580571] | 28520=expected
    1465/1934 - predicted=[27614.32902357] | 25126=expected
    1466/1934 - predicted=[24821.88911798] | 29177=expected
    1467/1934 - predicted=[28154.94157384] | 31042=expected
    1468/1934 - predicted=[29689.65256982] | 28773=expected
    1469/1934 - predicted=[27822.81050088] | 30008=expected
    1470/1934 - predicted=[28839.1181158] | 24505=expected
    1471/1934 - predicted=[24311.34663109] | 17175=expected
    1472/1934 - predicted=[18280.65356385] | 10681=expected
    1473/1934 - predicted=[12936.84773549] | 12935=expected
    1474/1934 - predicted=[14791.27438732] | 24834=expected
    1475/1934 - predicted=[24581.50001718] | 28478=expected
    1476/1934 - predicted=[27579.34157078] | 26540=expected
    1477/1934 - predicted=[25985.05634386] | 24260=expected
    1478/1934 - predicted=[24109.42273118] | 24144=expected
    1479/1934 - predicted=[24014.00697866] | 24955=expected
    1480/1934 - predicted=[24681.19237997] | 25829=expected
    1481/1934 - predicted=[25400.22295614] | 28575=expected
    1482/1934 - predicted=[27659.33369832] | 27907=expected
    1483/1934 - predicted=[27109.87205245] | 24143=expected
    1484/1934 - predicted=[24013.38696008] | 28353=expected
    1485/1934 - predicted=[27476.78881237] | 31004=expected
    1486/1934 - predicted=[29657.9043413] | 22589=expected
    1487/1934 - predicted=[22735.21013573] | 13423=expected
    1488/1934 - predicted=[15195.06983256] | 13140=expected
    1489/1934 - predicted=[14961.83517483] | 25477=expected
    1490/1934 - predicted=[25110.37563388] | 30078=expected
    1491/1934 - predicted=[28894.81443552] | 28099=expected
    1492/1934 - predicted=[27267.12504756] | 25505=expected
    1493/1934 - predicted=[25133.5876141] | 26235=expected
    1494/1934 - predicted=[25734.04695291] | 26405=expected
    1495/1934 - predicted=[25873.91984705] | 25777=expected
    1496/1934 - predicted=[25357.43140915] | 28645=expected
    1497/1934 - predicted=[27716.45081907] | 28518=expected
    1498/1934 - predicted=[27612.09524964] | 24390=expected
    1499/1934 - predicted=[24216.79934328] | 28398=expected
    1500/1934 - predicted=[27513.3954046] | 17322=expected
    1501/1934 - predicted=[18403.89376702] | 9926=expected
    1502/1934 - predicted=[12320.16329662] | 13246=expected
    1503/1934 - predicted=[15050.84489169] | 26021=expected
    1504/1934 - predicted=[25557.52108238] | 29648=expected
    1505/1934 - predicted=[28540.24216854] | 27364=expected
    1506/1934 - predicted=[26662.05601767] | 25866=expected
    1507/1934 - predicted=[25430.24394992] | 26027=expected
    1508/1934 - predicted=[25562.67925874] | 26983=expected
    1509/1934 - predicted=[26348.88416517] | 26440=expected
    1510/1934 - predicted=[25902.40818538] | 27287=expected
    1511/1934 - predicted=[26598.99388872] | 23463=expected
    1512/1934 - predicted=[23454.40477595] | 24076=expected
    1513/1934 - predicted=[23958.49216098] | 14409=expected
    1514/1934 - predicted=[16009.14108379] | 9025=expected
    1515/1934 - predicted=[11580.41544204] | 12825=expected
    1516/1934 - predicted=[14705.60475693] | 24036=expected
    1517/1934 - predicted=[23925.07282893] | 28648=expected
    1518/1934 - predicted=[27717.29657553] | 26908=expected
    1519/1934 - predicted=[26286.6378979] | 25736=expected
    1520/1934 - predicted=[25323.01254112] | 26272=expected
    1521/1934 - predicted=[25763.77435256] | 26789=expected
    1522/1934 - predicted=[26188.92966482] | 27382=expected
    1523/1934 - predicted=[26676.5925491] | 28686=expected
    1524/1934 - predicted=[27748.9262609] | 24380=expected
    1525/1934 - predicted=[24208.30715002] | 33263=expected
    1526/1934 - predicted=[31512.39356604] | 31791=expected
    1527/1934 - predicted=[30302.21263047] | 24552=expected
    1528/1934 - predicted=[24349.94845565] | 18417=expected
    1529/1934 - predicted=[19305.8769971] | 12788=expected
    1530/1934 - predicted=[14677.27964647] | 8295=expected
    1531/1934 - predicted=[10981.46881938] | 8865=expected
    1532/1934 - predicted=[11449.33859293] | 14766=expected
    1533/1934 - predicted=[16302.45718876] | 21318=expected
    1534/1934 - predicted=[21690.13712025] | 28672=expected
    1535/1934 - predicted=[27736.72824546] | 31916=expected
    1536/1934 - predicted=[30404.3273976] | 33512=expected
    1537/1934 - predicted=[31717.11802887] | 33768=expected
    1538/1934 - predicted=[31928.05881427] | 32845=expected
    1539/1934 - predicted=[31169.33779667] | 32806=expected
    1540/1934 - predicted=[31137.59439322] | 28395=expected
    1541/1934 - predicted=[27510.19314991] | 32300=expected
    1542/1934 - predicted=[30721.6693871] | 37177=expected
    1543/1934 - predicted=[34733.43664101] | 36825=expected
    1544/1934 - predicted=[34444.66533521] | 30150=expected
    1545/1934 - predicted=[28954.41078159] | 31134=expected
    1546/1934 - predicted=[29763.88581403] | 33487=expected
    1547/1934 - predicted=[31699.4973972] | 35036=expected
    1548/1934 - predicted=[32974.1289202] | 30209=expected
    1549/1934 - predicted=[29003.85962679] | 24240=expected
    1550/1934 - predicted=[24094.76392701] | 18787=expected
    1551/1934 - predicted=[19610.26614873] | 13179=expected
    1552/1934 - predicted=[14997.80944427] | 8708=expected
    1553/1934 - predicted=[11319.27760786] | 6773=expected
    1554/1934 - predicted=[9725.97297853] | 11514=expected
    1555/1934 - predicted=[13626.22249462] | 18166=expected
    1556/1934 - predicted=[19098.18168042] | 26183=expected
    1557/1934 - predicted=[25691.92867233] | 29515=expected
    1558/1934 - predicted=[28432.44635809] | 31160=expected
    1559/1934 - predicted=[29785.65738137] | 30393=expected
    1560/1934 - predicted=[29154.9706008] | 30257=expected
    1561/1934 - predicted=[29043.2811729] | 30218=expected
    1562/1934 - predicted=[29011.37538846] | 28222=expected
    1563/1934 - predicted=[27369.70400048] | 27853=expected
    1564/1934 - predicted=[27066.28161858] | 28534=expected
    1565/1934 - predicted=[27626.51538119] | 24988=expected
    1566/1934 - predicted=[24709.91683067] | 23304=expected
    1567/1934 - predicted=[23324.85294244] | 21885=expected
    1568/1934 - predicted=[22157.73061162] | 18989=expected
    1569/1934 - predicted=[19775.7331204] | 12985=expected
    1570/1934 - predicted=[14836.9414632] | 8181=expected
    1571/1934 - predicted=[10883.86082348] | 13186=expected
    1572/1934 - predicted=[15001.43125026] | 23988=expected
    1573/1934 - predicted=[23886.82686706] | 26415=expected
    1574/1934 - predicted=[25882.96176084] | 23083=expected
    1575/1934 - predicted=[23142.55023964] | 21253=expected
    1576/1934 - predicted=[21637.4513136] | 22532=expected
    1577/1934 - predicted=[22689.34380806] | 23494=expected
    1578/1934 - predicted=[23480.53104012] | 24281=expected
    1579/1934 - predicted=[24127.80182297] | 26996=expected
    1580/1934 - predicted=[26360.78438259] | 29056=expected
    1581/1934 - predicted=[28055.16701314] | 25618=expected
    1582/1934 - predicted=[25227.55863608] | 29383=expected
    1583/1934 - predicted=[28324.19147535] | 31548=expected
    1584/1934 - predicted=[30105.11702563] | 29795=expected
    1585/1934 - predicted=[28663.38658034] | 31637=expected
    1586/1934 - predicted=[30178.70656679] | 28649=expected
    1587/1934 - predicted=[27721.07112251] | 19935=expected
    1588/1934 - predicted=[20554.12689767] | 11120=expected
    1589/1934 - predicted=[13303.73482406] | 12667=expected
    1590/1934 - predicted=[14575.82288378] | 23826=expected
    1591/1934 - predicted=[23753.82671052] | 28274=expected
    1592/1934 - predicted=[27411.6948172] | 26373=expected
    1593/1934 - predicted=[25848.43567055] | 23977=expected
    1594/1934 - predicted=[23878.11257086] | 24538=expected
    1595/1934 - predicted=[24339.45757155] | 25251=expected
    1596/1934 - predicted=[24925.81012005] | 27114=expected
    1597/1934 - predicted=[26457.88991502] | 28395=expected
    1598/1934 - predicted=[27511.42726826] | 26943=expected
    1599/1934 - predicted=[26317.41224947] | 24209=expected
    1600/1934 - predicted=[24069.12161438] | 27997=expected
    1601/1934 - predicted=[27184.21467596] | 33002=expected
    1602/1934 - predicted=[31300.50735502] | 25524=expected
    1603/1934 - predicted=[25150.6501336] | 15127=expected
    1604/1934 - predicted=[16601.30662854] | 7928=expected
    1605/1934 - predicted=[10680.03481286] | 13886=expected
    1606/1934 - predicted=[15580.22311035] | 26308=expected
    1607/1934 - predicted=[25794.50684837] | 31065=expected
    1608/1934 - predicted=[29705.80581655] | 28924=expected
    1609/1934 - predicted=[27945.54250134] | 27371=expected
    1610/1934 - predicted=[26668.74287626] | 27333=expected
    1611/1934 - predicted=[26637.56833807] | 27838=expected
    1612/1934 - predicted=[27052.85728] | 27345=expected
    1613/1934 - predicted=[26647.58482907] | 29173=expected
    1614/1934 - predicted=[28150.6927102] | 28832=expected
    1615/1934 - predicted=[27870.43042017] | 24751=expected
    1616/1934 - predicted=[24515.01135577] | 29492=expected
    1617/1934 - predicted=[28413.10453981] | 28219=expected
    1618/1934 - predicted=[27366.51751439] | 18838=expected
    1619/1934 - predicted=[19653.77375816] | 9979=expected
    1620/1934 - predicted=[12369.51003669] | 14193=expected
    1621/1934 - predicted=[15834.40705576] | 25303=expected
    1622/1934 - predicted=[24968.38611211] | 29465=expected
    1623/1934 - predicted=[28389.86817767] | 28001=expected
    1624/1934 - predicted=[27186.43762184] | 25612=expected
    1625/1934 - predicted=[25222.57440871] | 26565=expected
    1626/1934 - predicted=[26006.03468928] | 27460=expected
    1627/1934 - predicted=[26741.84339618] | 27158=expected
    1628/1934 - predicted=[26493.64627775] | 29386=expected
    1629/1934 - predicted=[28325.34733426] | 28382=expected
    1630/1934 - predicted=[27500.06527334] | 22858=expected
    1631/1934 - predicted=[22958.98389817] | 25044=expected
    1632/1934 - predicted=[24755.97166287] | 19285=expected
    1633/1934 - predicted=[20021.87549717] | 11012=expected
    1634/1934 - predicted=[13220.49471894] | 5552=expected
    1635/1934 - predicted=[8729.42400346] | 13429=expected
    1636/1934 - predicted=[15206.89118931] | 24689=expected
    1637/1934 - predicted=[24463.44526542] | 29553=expected
    1638/1934 - predicted=[28461.59014036] | 28445=expected
    1639/1934 - predicted=[27550.9214154] | 26865=expected
    1640/1934 - predicted=[26252.24645884] | 27997=expected
    1641/1934 - predicted=[27182.80894882] | 27711=expected
    1642/1934 - predicted=[26947.8016666] | 27692=expected
    1643/1934 - predicted=[26932.26045865] | 29513=expected
    1644/1934 - predicted=[28429.26127763] | 26266=expected
    1645/1934 - predicted=[25760.23891848] | 20157=expected
    1646/1934 - predicted=[20738.81784904] | 23445=expected
    1647/1934 - predicted=[23441.40119371] | 29644=expected
    1648/1934 - predicted=[28536.70410722] | 32830=expected
    1649/1934 - predicted=[31155.88286649] | 26730=expected
    1650/1934 - predicted=[26141.68085024] | 20526=expected
    1651/1934 - predicted=[21042.51122896] | 14215=expected
    1652/1934 - predicted=[15855.14804734] | 9223=expected
    1653/1934 - predicted=[11750.72818284] | 5914=expected
    1654/1934 - predicted=[9028.50306971] | 8839=expected
    1655/1934 - predicted=[11432.92598445] | 14537=expected
    1656/1934 - predicted=[16117.80291957] | 21550=expected
    1657/1934 - predicted=[21883.01018567] | 27584=expected
    1658/1934 - predicted=[26842.93291574] | 31641=expected
    1659/1934 - predicted=[30178.04722317] | 34107=expected
    1660/1934 - predicted=[32205.73831729] | 34776=expected
    1661/1934 - predicted=[32756.27501912] | 34290=expected
    1662/1934 - predicted=[32357.15266041] | 33144=expected
    1663/1934 - predicted=[31415.25761243] | 27170=expected
    1664/1934 - predicted=[26503.73000521] | 30127=expected
    1665/1934 - predicted=[28934.80138132] | 34794=expected
    1666/1934 - predicted=[32772.24390687] | 37038=expected
    1667/1934 - predicted=[34618.21306653] | 31176=expected
    1668/1934 - predicted=[29798.06251769] | 30125=expected
    1669/1934 - predicted=[28934.1076648] | 34301=expected
    1670/1934 - predicted=[32368.07031054] | 34176=expected
    1671/1934 - predicted=[32265.72845696] | 31962=expected
    1672/1934 - predicted=[30445.41764606] | 28228=expected
    1673/1934 - predicted=[27375.20571394] | 23745=expected
    1674/1934 - predicted=[23689.32246243] | 17573=expected
    1675/1934 - predicted=[18614.83677516] | 11182=expected
    1676/1934 - predicted=[13359.49232306] | 6344=expected
    1677/1934 - predicted=[9379.35477691] | 10513=expected
    1678/1934 - predicted=[12807.83986875] | 17284=expected
    1679/1934 - predicted=[18376.11563712] | 25295=expected
    1680/1934 - predicted=[24962.96396401] | 28393=expected
    1681/1934 - predicted=[27510.18454936] | 32071=expected
    1682/1934 - predicted=[30534.57322124] | 31623=expected
    1683/1934 - predicted=[30166.43785285] | 31122=expected
    1684/1934 - predicted=[29754.69132683] | 29622=expected
    1685/1934 - predicted=[28521.40649778] | 27734=expected
    1686/1934 - predicted=[26969.05286512] | 27366=expected
    1687/1934 - predicted=[26666.5359954] | 28309=expected
    1688/1934 - predicted=[27442.01467202] | 26414=expected
    1689/1934 - predicted=[25883.88560594] | 23786=expected
    1690/1934 - predicted=[23723.04899209] | 22629=expected
    1691/1934 - predicted=[22771.71998568] | 18318=expected
    1692/1934 - predicted=[19226.99962536] | 13564=expected
    1693/1934 - predicted=[15317.58185214] | 8176=expected
    1694/1934 - predicted=[10885.52105117] | 12246=expected
    1695/1934 - predicted=[14232.70993972] | 21631=expected
    1696/1934 - predicted=[21950.53061351] | 26012=expected
    1697/1934 - predicted=[25552.71917319] | 24002=expected
    1698/1934 - predicted=[23900.06630632] | 22634=expected
    1699/1934 - predicted=[22775.27022152] | 22891=expected
    1700/1934 - predicted=[22986.57099651] | 24706=expected
    1701/1934 - predicted=[24478.89988829] | 24605=expected
    1702/1934 - predicted=[24395.87352933] | 27042=expected
    1703/1934 - predicted=[26399.66408662] | 27851=expected
    1704/1934 - predicted=[27064.92875923] | 24289=expected
    1705/1934 - predicted=[24136.17543395] | 27647=expected
    1706/1934 - predicted=[26897.21391403] | 31893=expected
    1707/1934 - predicted=[30388.67074431] | 30876=expected
    1708/1934 - predicted=[29552.60343873] | 29273=expected
    1709/1934 - predicted=[28234.61370757] | 29933=expected
    1710/1934 - predicted=[28777.46800927] | 28181=expected
    1711/1934 - predicted=[27336.92334314] | 20190=expected
    1712/1934 - predicted=[20766.44510612] | 12682=expected
    1713/1934 - predicted=[14592.82030646] | 12790=expected
    1714/1934 - predicted=[14681.1974691] | 23091=expected
    1715/1934 - predicted=[23151.36763021] | 26751=expected
    1716/1934 - predicted=[26160.45232601] | 24725=expected
    1717/1934 - predicted=[24494.80356187] | 23367=expected
    1718/1934 - predicted=[23378.34362582] | 23852=expected
    1719/1934 - predicted=[23777.08399609] | 26343=expected
    1720/1934 - predicted=[25825.0621901] | 26549=expected
    1721/1934 - predicted=[25994.47362649] | 28279=expected
    1722/1934 - predicted=[27416.88609431] | 28079=expected
    1723/1934 - predicted=[27252.54206057] | 24458=expected
    1724/1934 - predicted=[24275.5295194] | 27930=expected
    1725/1934 - predicted=[27130.0633599] | 32624=expected
    1726/1934 - predicted=[30989.61580542] | 31815=expected
    1727/1934 - predicted=[30324.68422076] | 30625=expected
    1728/1934 - predicted=[29346.41242489] | 32092=expected
    1729/1934 - predicted=[30552.90545205] | 25060=expected
    1730/1934 - predicted=[24771.03226048] | 15755=expected
    1731/1934 - predicted=[17120.98806939] | 8888=expected
    1732/1934 - predicted=[11473.99170981] | 12441=expected
    1733/1934 - predicted=[14395.3704186] | 23066=expected
    1734/1934 - predicted=[23131.22800011] | 27581=expected
    1735/1934 - predicted=[26842.90514388] | 25714=expected
    1736/1934 - predicted=[25308.13049078] | 24825=expected
    1737/1934 - predicted=[24577.33806309] | 25726=expected
    1738/1934 - predicted=[25318.04812765] | 27619=expected
    1739/1934 - predicted=[26874.2932249] | 27726=expected
    1740/1934 - predicted=[26962.33482524] | 29584=expected
    1741/1934 - predicted=[28489.92015962] | 29376=expected
    1742/1934 - predicted=[28319.05255409] | 25436=expected
    1743/1934 - predicted=[25079.99047967] | 28858=expected
    1744/1934 - predicted=[27893.24399596] | 34786=expected
    1745/1934 - predicted=[32767.26387686] | 32976=expected
    1746/1934 - predicted=[31279.37296366] | 27700=expected
    1747/1934 - predicted=[26941.65836861] | 17784=expected
    1748/1934 - predicted=[18790.05767232] | 10553=expected
    1749/1934 - predicted=[12844.9372888] | 5392=expected
    1750/1934 - predicted=[8599.5103051] | 12042=expected
    1751/1934 - predicted=[14068.10878049] | 22009=expected
    1752/1934 - predicted=[22262.56191143] | 26541=expected
    1753/1934 - predicted=[25987.98226358] | 26560=expected
    1754/1934 - predicted=[26003.65307987] | 24953=expected
    1755/1934 - predicted=[24682.68777013] | 25625=expected
    1756/1934 - predicted=[25235.11280103] | 27651=expected
    1757/1934 - predicted=[26900.60229312] | 27003=expected
    1758/1934 - predicted=[26367.98325293] | 29342=expected
    1759/1934 - predicted=[28290.85496531] | 29248=expected
    1760/1934 - predicted=[28213.71263963] | 24582=expected
    1761/1934 - predicted=[24378.04411082] | 34736=expected
    1762/1934 - predicted=[32725.11579974] | 31153=expected
    1763/1934 - predicted=[29779.70601488] | 33289=expected
    1764/1934 - predicted=[31536.00738529] | 27926=expected
    1765/1934 - predicted=[27127.2404528] | 20182=expected
    1766/1934 - predicted=[20761.80135607] | 13329=expected
    1767/1934 - predicted=[15128.48321018] | 8671=expected
    1768/1934 - predicted=[11298.17704143] | 10699=expected
    1769/1934 - predicted=[12965.01247576] | 17219=expected
    1770/1934 - predicted=[18325.37296225] | 22127=expected
    1771/1934 - predicted=[22359.83235217] | 22765=expected
    1772/1934 - predicted=[22884.24713708] | 23487=expected
    1773/1934 - predicted=[23477.71757199] | 26560=expected
    1774/1934 - predicted=[26003.70507007] | 28740=expected
    1775/1934 - predicted=[27795.75543616] | 29034=expected
    1776/1934 - predicted=[28037.54882055] | 30107=expected
    1777/1934 - predicted=[28919.75225507] | 28635=expected
    1778/1934 - predicted=[27709.80512115] | 25176=expected
    1779/1934 - predicted=[24866.45516544] | 28240=expected
    1780/1934 - predicted=[27385.15241369] | 30174=expected
    1781/1934 - predicted=[28975.12191386] | 29261=expected
    1782/1934 - predicted=[28224.71590839] | 24448=expected
    1783/1934 - predicted=[24268.29812015] | 24764=expected
    1784/1934 - predicted=[24528.06761106] | 25785=expected
    1785/1934 - predicted=[25367.36248314] | 23367=expected
    1786/1934 - predicted=[23379.7729082] | 18755=expected
    1787/1934 - predicted=[19588.68399294] | 15129=expected
    1788/1934 - predicted=[16607.79308271] | 12248=expected
    1789/1934 - predicted=[14238.85835071] | 9237=expected
    1790/1934 - predicted=[11762.34407191] | 7125=expected
    1791/1934 - predicted=[10024.30980455] | 10514=expected
    1792/1934 - predicted=[12810.81158048] | 16443=expected
    1793/1934 - predicted=[17686.09982853] | 23176=expected
    1794/1934 - predicted=[23221.69726159] | 26716=expected
    1795/1934 - predicted=[26131.99516097] | 29366=expected
    1796/1934 - predicted=[28310.74072146] | 26540=expected
    1797/1934 - predicted=[25987.43135204] | 23476=expected
    1798/1934 - predicted=[23468.50115455] | 23928=expected
    1799/1934 - predicted=[23840.09476387] | 23583=expected
    1800/1934 - predicted=[23556.4742212] | 24956=expected
    1801/1934 - predicted=[24685.23185485] | 30336=expected
    1802/1934 - predicted=[29108.27622645] | 24212=expected
    1803/1934 - predicted=[24073.67402957] | 19318=expected
    1804/1934 - predicted=[20050.46973083] | 19027=expected
    1805/1934 - predicted=[19811.16631769] | 20205=expected
    1806/1934 - predicted=[20779.51642144] | 16730=expected
    1807/1934 - predicted=[17922.64919061] | 13118=expected
    1808/1934 - predicted=[14952.71703222] | 10003=expected
    1809/1934 - predicted=[12390.70793581] | 7968=expected
    1810/1934 - predicted=[10716.10757853] | 11579=expected
    1811/1934 - predicted=[13685.36418188] | 16874=expected
    1812/1934 - predicted=[18039.42120848] | 19121=expected
    1813/1934 - predicted=[19886.88474373] | 21197=expected
    1814/1934 - predicted=[21593.73769176] | 20932=expected
    1815/1934 - predicted=[21375.81893029] | 22676=expected
    1816/1934 - predicted=[22809.70137853] | 24311=expected
    1817/1934 - predicted=[24153.97680745] | 23345=expected
    1818/1934 - predicted=[23359.75142113] | 23826=expected
    1819/1934 - predicted=[23755.22440093] | 21997=expected
    1820/1934 - predicted=[22251.44288703] | 19890=expected
    1821/1934 - predicted=[20519.05082764] | 18216=expected
    1822/1934 - predicted=[19142.58963201] | 18905=expected
    1823/1934 - predicted=[19709.00942543] | 17116=expected
    1824/1934 - predicted=[18237.91759123] | 13853=expected
    1825/1934 - predicted=[15554.55883226] | 10725=expected
    1826/1934 - predicted=[12981.6142368] | 10068=expected
    1827/1934 - predicted=[12440.50811186] | 13800=expected
    1828/1934 - predicted=[15509.6469714] | 15017=expected
    1829/1934 - predicted=[16510.25703818] | 15580=expected
    1830/1934 - predicted=[16973.04660945] | 16614=expected
    1831/1934 - predicted=[17823.23321167] | 17904=expected
    1832/1934 - predicted=[18883.99822958] | 16938=expected
    1833/1934 - predicted=[18089.42148199] | 16763=expected
    1834/1934 - predicted=[17945.33888511] | 17048=expected
    1835/1934 - predicted=[18179.57805009] | 16114=expected
    1836/1934 - predicted=[17411.23809957] | 15779=expected
    1837/1934 - predicted=[17135.50864639] | 16403=expected
    1838/1934 - predicted=[17648.54485241] | 14212=expected
    1839/1934 - predicted=[15846.18166935] | 10268=expected
    1840/1934 - predicted=[12601.31075112] | 8951=expected
    1841/1934 - predicted=[11516.91299306] | 12416=expected
    1842/1934 - predicted=[14367.23482999] | 15387=expected
    1843/1934 - predicted=[16811.11889987] | 18481=expected
    1844/1934 - predicted=[19356.14256179] | 21131=expected
    1845/1934 - predicted=[21535.87586846] | 23279=expected
    1846/1934 - predicted=[23302.67204178] | 24108=expected
    1847/1934 - predicted=[23984.55569396] | 25720=expected
    1848/1934 - predicted=[25310.50264637] | 26802=expected
    1849/1934 - predicted=[26200.54033969] | 25598=expected
    1850/1934 - predicted=[25210.23603403] | 25917=expected
    1851/1934 - predicted=[25472.66286727] | 26693=expected
    1852/1934 - predicted=[26111.00606634] | 23399=expected
    1853/1934 - predicted=[23401.57405367] | 20525=expected
    1854/1934 - predicted=[21037.6019908] | 21749=expected
    1855/1934 - predicted=[22044.35181488] | 18333=expected
    1856/1934 - predicted=[19234.50765783] | 13071=expected
    1857/1934 - predicted=[14905.78173788] | 8710=expected
    1858/1934 - predicted=[11317.08971438] | 7528=expected
    1859/1934 - predicted=[10343.31159036] | 10215=expected
    1860/1934 - predicted=[12553.76992623] | 15155=expected
    1861/1934 - predicted=[16618.33356588] | 19042=expected
    1862/1934 - predicted=[19816.18046632] | 21289=expected
    1863/1934 - predicted=[21664.68879956] | 24008=expected
    1864/1934 - predicted=[23901.48521322] | 26430=expected
    1865/1934 - predicted=[25893.98093735] | 27498=expected
    1866/1934 - predicted=[26772.6538901] | 26993=expected
    1867/1934 - predicted=[26357.26641748] | 27513=expected
    1868/1934 - predicted=[26785.1256744] | 25348=expected
    1869/1934 - predicted=[25004.07671187] | 25903=expected
    1870/1934 - predicted=[25460.688975] | 27253=expected
    1871/1934 - predicted=[26571.3502297] | 26229=expected
    1872/1934 - predicted=[25728.97874391] | 22475=expected
    1873/1934 - predicted=[22640.71303345] | 24646=expected
    1874/1934 - predicted=[24426.69505169] | 23262=expected
    1875/1934 - predicted=[23288.15227697] | 18678=expected
    1876/1934 - predicted=[19517.08693085] | 11497=expected
    1877/1934 - predicted=[13608.9124867] | 8126=expected
    1878/1934 - predicted=[10834.06841576] | 11404=expected
    1879/1934 - predicted=[13531.1211798] | 16594=expected
    1880/1934 - predicted=[17801.53616191] | 20582=expected
    1881/1934 - predicted=[21082.58007538] | 23099=expected
    1882/1934 - predicted=[23153.3029744] | 25495=expected
    1883/1934 - predicted=[25124.49052449] | 28773=expected
    1884/1934 - predicted=[27821.38891064] | 29251=expected
    1885/1934 - predicted=[28214.77942434] | 30357=expected
    1886/1934 - predicted=[29124.9051553] | 30043=expected
    1887/1934 - predicted=[28866.71726657] | 26805=expected
    1888/1934 - predicted=[26202.69376038] | 28503=expected
    1889/1934 - predicted=[27599.78560028] | 30720=expected
    1890/1934 - predicted=[29424.02432938] | 27648=expected
    1891/1934 - predicted=[26896.53280593] | 24042=expected
    1892/1934 - predicted=[23929.77060951] | 26000=expected
    1893/1934 - predicted=[25540.68188211] | 22804=expected
    1894/1934 - predicted=[22911.28387507] | 19032=expected
    1895/1934 - predicted=[19807.96552329] | 14484=expected
    1896/1934 - predicted=[16065.8881895] | 8918=expected
    1897/1934 - predicted=[11485.09185405] | 7576=expected
    1898/1934 - predicted=[10379.45044574] | 10677=expected
    1899/1934 - predicted=[12931.17020704] | 15122=expected
    1900/1934 - predicted=[16589.12008153] | 18974=expected
    1901/1934 - predicted=[19758.81783783] | 21745=expected
    1902/1934 - predicted=[22038.87601245] | 24025=expected
    1903/1934 - predicted=[23914.90746032] | 26290=expected
    1904/1934 - predicted=[25778.62604398] | 27506=expected
    1905/1934 - predicted=[26779.25359629] | 28956=expected
    1906/1934 - predicted=[27972.48690221] | 29641=expected
    1907/1934 - predicted=[28536.2940186] | 27195=expected
    1908/1934 - predicted=[26523.62057432] | 28227=expected
    1909/1934 - predicted=[27372.89456963] | 29979=expected
    1910/1934 - predicted=[28814.71728759] | 28149=expected
    1911/1934 - predicted=[27308.9199497] | 23482=expected
    1912/1934 - predicted=[23468.65500842] | 24047=expected
    1913/1934 - predicted=[23933.56332156] | 24371=expected
    1914/1934 - predicted=[24200.17411859] | 22163=expected
    1915/1934 - predicted=[22383.34899785] | 18624=expected
    1916/1934 - predicted=[19471.26256731] | 14456=expected
    1917/1934 - predicted=[16041.28023714] | 11271=expected
    1918/1934 - predicted=[13419.59229451] | 8726=expected
    1919/1934 - predicted=[11323.93743344] | 8647=expected
    1920/1934 - predicted=[11257.95099412] | 13681=expected
    1921/1934 - predicted=[15401.52119706] | 17940=expected
    1922/1934 - predicted=[18906.79476632] | 22328=expected
    1923/1934 - predicted=[22518.00452099] | 23430=expected
    1924/1934 - predicted=[23424.89147684] | 24051=expected
    1925/1934 - predicted=[23935.94934174] | 23594=expected
    1926/1934 - predicted=[23559.86599845] | 24649=expected
    1927/1934 - predicted=[24428.09026539] | 24420=expected
    1928/1934 - predicted=[24239.64953099] | 25058=expected
    1929/1934 - predicted=[24764.71306738] | 25859=expected
    1930/1934 - predicted=[25423.93290871] | 25771=expected
    1931/1934 - predicted=[25351.54855545] | 20674=expected
    1932/1934 - predicted=[21156.97716249] | 21254=expected
    1933/1934 - predicted=[21634.24979683] | 22562=expected
    1934/1934 - predicted=[22710.63945612] | 20885=expected
    Test MSE: 15066096.918462574



```python
mpl.plot(test_set_list)
mpl.plot(predictions, color='orange')
mpl.show()
```


![png](output_16_0.png)



```python
mpl.plot(test_set_list[1600:])
mpl.plot(predictions[1600:], color='orange')
mpl.show()
```


![png](output_17_0.png)



```python
mpl.plot(test_set_list[1800:])
mpl.plot(predictions[1800:], color='orange')
mpl.show()
```


![png](output_18_0.png)

